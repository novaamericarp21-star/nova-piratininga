import { images } from '../data/images';
import { useSEO } from '../hooks/useSEO';
import { PageHero } from '../components/PageHero';
import { Timeline } from '../sections/Timeline';
import { ContactCta } from '../sections/ContactCta';

export default function History() {
  useSEO({
    title: 'Nossa história',
    description:
      'Da fundação em 15 de dezembro de 2010 às ampliações do confinamento, da genética e da agricultura: os marcos da Fazenda Nova Piratininga.',
    path: '/historia',
    image: images.aboutHero.src,
  });

  return (
    <>
      <PageHero
        title="Nossa história"
        subtitle="Os marcos da fazenda, da fundação em 2010 às ampliações mais recentes divulgadas pela empresa."
        image={images.history2010}
        className="min-h-[68svh]"
      />
      <Timeline />
      <ContactCta />
    </>
  );
}
