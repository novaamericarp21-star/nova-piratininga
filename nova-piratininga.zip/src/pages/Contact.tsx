import { Phone, MapPin } from 'lucide-react';
import { company } from '../data/company';
import { images } from '../data/images';
import { useSEO } from '../hooks/useSEO';
import { Container } from '../components/Container';
import { ContactForm } from '../components/ContactForm';
import { PageHero } from '../components/PageHero';
import { Reveal } from '../components/Reveal';
import { SocialLinks } from '../components/Social';
import { TopoMap } from '../sections/MapSection';

export default function Contact() {
  useSEO({
    title: 'Contato',
    description:
      'Fale com a Fazenda Nova Piratininga: formulário, telefones e endereço em São Miguel do Araguaia (GO).',
    path: '/contato',
    image: images.contactHero.src,
  });
  const { address } = company;

  return (
    <>
      <PageHero title="Fale com a Nova Piratininga" image={images.contactHero} className="min-h-[64svh]" />

      <Container className="py-24 md:py-36">
        <div className="grid gap-16 lg:grid-cols-12 lg:gap-24">
          <div className="lg:col-span-7">
            <h2 className="display-md">Envie uma mensagem</h2>
            <p className="body-copy mt-4 max-w-md">
              Conte o que você precisa. Retornamos pelo e-mail ou telefone informado.
            </p>
            <div className="mt-12">
              <ContactForm />
            </div>
          </div>

          <aside className="lg:col-span-5">
            <Reveal>
              <h2 className="display-md">{address.city}</h2>
              <address className="mt-6 not-italic">
                <p className="flex gap-3 text-sand/85">
                  <MapPin size={18} strokeWidth={1.4} className="mt-1 shrink-0 text-moss" aria-hidden="true" />
                  <span>
                    {address.line1}
                    <br />
                    {address.line2}
                    <br />
                    CEP {address.postalCode} · {address.state}
                  </span>
                </p>
                <div className="mt-6 flex gap-3">
                  <Phone size={18} strokeWidth={1.4} className="mt-3 shrink-0 text-moss" aria-hidden="true" />
                  <ul>
                    {company.phones.map((p) => (
                      <li key={p.href}>
                        <a
                          href={p.href}
                          className="link-line inline-flex min-h-11 items-center text-[1.05rem] text-bone"
                        >
                          {p.display}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </address>

              <div className="mt-8">
                <p className="text-[0.85rem] font-semibold text-stone">Redes sociais</p>
                <SocialLinks className="-ml-3 mt-1" />
              </div>

              <div className="mt-12">
                <TopoMap label={false} />
                <a
                  href={company.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-line mt-4 inline-flex min-h-11 items-center text-bone"
                >
                  Abrir endereço no Google Maps
                </a>
              </div>
            </Reveal>
          </aside>
        </div>
      </Container>
    </>
  );
}
