import { images } from '../data/images';
import { agricultureSections, techItems } from '../data/content';
import { agricultureStats, soyGoal } from '../data/stats';
import { useSEO } from '../hooks/useSEO';
import { Container } from '../components/Container';
import { StatItem } from '../components/CountUp';
import { TechIcon } from '../components/Icons';
import { PageHero } from '../components/PageHero';
import { ParallaxImg } from '../components/ParallaxImg';
import { ClipReveal, Reveal } from '../components/Reveal';
import { SectionsWithNav } from '../components/SectionsWithNav';
import { TopoLines } from '../components/TopoLines';
import { Gallery } from '../sections/Gallery';
import { ContactCta } from '../sections/ContactCta';

const techIds = ['precisao', 'irrigacao', 'armazenagem', 'ilp'];

export default function Agriculture() {
  useSEO({
    title: 'Agricultura',
    description:
      'Cultivo de soja e milho em larga escala, com agricultura de precisão, pivôs de irrigação, armazenagem própria de grãos e foco na integração lavoura-pecuária.',
    path: '/agricultura',
    image: images.agricultureHero.src,
  });

  const tech = techItems.filter((t) => techIds.includes(t.id));

  return (
    <>
      <PageHero
        title="Agricultura"
        subtitle="A tecnologia encontra a terra para transformar produtividade em resultado."
        image={images.agricultureHero}
      />

      <section className="relative isolate overflow-hidden py-24 md:py-36">
        <TopoLines
          className="pointer-events-none absolute inset-0 -z-10 h-full w-full text-forest-600/[0.16]"
          cx={720}
          cy={380}
          rings={18}
          step={34}
          seed={4.2}
        />
        <Container>
          <div className="grid gap-14 lg:grid-cols-12 lg:gap-20">
            <div className="lg:col-span-5">
              {agricultureStats.map((s) => (
                <StatItem key={s.id} stat={s} />
              ))}
              <Reveal className="mt-10">
                <p className="max-w-sm border-l-2 border-moss pl-4 text-[0.98rem] leading-relaxed text-sand/85">
                  {soyGoal.text}
                </p>
              </Reveal>
            </div>
            <ul className="grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:col-span-7">
              {tech.map((t) => (
                <li key={t.id} className="border-t border-white/[0.09] pt-6">
                  <TechIcon id={t.icon} className="h-9 w-9 text-moss" />
                  <h3 className="mt-5 font-display text-[1.45rem] font-light text-bone">{t.title}</h3>
                  <p className="body-copy mt-2 max-w-xs">{t.text}</p>
                </li>
              ))}
            </ul>
          </div>
        </Container>
      </section>

      <Container>
        <ClipReveal>
          <ParallaxImg image={images.agricultureFeature} className="aspect-[4/3] md:aspect-[21/9]" />
        </ClipReveal>
      </Container>

      <SectionsWithNav sections={agricultureSections} />
      <Gallery only="Agricultura" title="Agricultura em imagens" compact />
      <ContactCta />
    </>
  );
}
