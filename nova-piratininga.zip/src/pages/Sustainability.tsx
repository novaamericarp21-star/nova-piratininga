import { images } from '../data/images';
import { sustainabilityPillars } from '../data/content';
import { sustainabilityStats, statsReference } from '../data/stats';
import { useSEO } from '../hooks/useSEO';
import { Container } from '../components/Container';
import { StatItem } from '../components/CountUp';
import { PageHero } from '../components/PageHero';
import { Reveal } from '../components/Reveal';
import { People } from '../sections/People';
import { Gallery } from '../sections/Gallery';
import { ContactCta } from '../sections/ContactCta';

export default function Sustainability() {
  useSEO({
    title: 'Sustentabilidade',
    description:
      'Produzir, preservar, evoluir: a Nova Piratininga mantém extensa área de preservação ambiental (APP) e reserva legal e conduz a integração lavoura-pecuária de forma sustentável.',
    path: '/sustentabilidade',
    image: images.water.src,
  });

  return (
    <>
      <PageHero title={'Produzir.\nPreservar.\nEvoluir.'} image={images.water} />

      <Container className="py-24 md:py-40">
        <Reveal>
          <p className="display-md max-w-3xl">
            Comprometida com a sustentabilidade, a Nova Piratininga mantém extensa área de preservação ambiental e
            reserva legal.
          </p>
        </Reveal>

        <ul className="mt-20 grid gap-12 md:grid-cols-3 md:gap-12">
          {sustainabilityPillars.map((p) => (
            <li key={p.id} className="border-t border-white/[0.14] pt-6">
              <h2 className="font-display text-[1.7rem] font-light text-bone">{p.title}</h2>
              <p className="body-copy mt-3 max-w-sm">{p.text}</p>
            </li>
          ))}
        </ul>

        {sustainabilityStats.length > 0 && (
          <div className="mt-24 border-t border-white/[0.09] pt-14">
            <div className="grid grid-cols-2 gap-x-8 gap-y-12 lg:grid-cols-4">
              {sustainabilityStats.map((s) => (
                <StatItem key={s.id} stat={s} />
              ))}
            </div>
            <p className="mt-10 text-[0.8rem] text-stone">{statsReference}</p>
          </div>
        )}
      </Container>

      <People />
      <Gallery only="Natureza" title="Natureza em imagens" compact />
      <ContactCta />
    </>
  );
}
