import { company } from '../data/company';
import { useSEO } from '../hooks/useSEO';
import { Hero } from '../sections/Hero';
import { Scale } from '../sections/Scale';
import { MapSection } from '../sections/MapSection';
import { Technology } from '../sections/Technology';
import { LivestockSection } from '../sections/LivestockSection';
import { AgricultureSection } from '../sections/AgricultureSection';
import { Integration } from '../sections/Integration';
import { SustainabilitySection } from '../sections/SustainabilitySection';
import { People } from '../sections/People';
import { Timeline } from '../sections/Timeline';
import { Gallery } from '../sections/Gallery';
import { ContactCta } from '../sections/ContactCta';

export default function Home() {
  useSEO({
    title: company.name,
    description:
      'Agropecuária brasileira integrada entre Goiás e Tocantins. Pecuária de ciclo completo com Nelore e Angus e agricultura de soja e milho, com foco em qualidade, produtividade e responsabilidade socioambiental.',
    path: '/',
  });

  return (
    <>
      <Hero />
      <Scale />
      <MapSection />
      <Technology />
      <LivestockSection />
      <AgricultureSection />
      <Integration />
      <SustainabilitySection />
      <People />
      <Timeline />
      <Gallery />
      <ContactCta />
    </>
  );
}
