import { useSEO } from '../hooks/useSEO';
import { Button } from '../components/Button';
import { Container } from '../components/Container';

export default function NotFound() {
  useSEO({ title: 'Página não encontrada', description: 'A página que você procura não existe ou mudou de endereço.', path: '/404' });
  return (
    <Container className="flex min-h-[100svh] flex-col justify-center py-40">
      <h1 className="display-xl">Página não encontrada.</h1>
      <p className="lead mt-6 max-w-md">O endereço pode ter mudado. Volte ao início ou fale com a gente.</p>
      <div className="mt-10 flex flex-wrap gap-3">
        <Button to="/">Ir para o início</Button>
        <Button to="/contato" variant="outline">
          Contato
        </Button>
      </div>
    </Container>
  );
}
