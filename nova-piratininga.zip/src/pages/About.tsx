import { aboutBlocks } from '../data/content';
import { images } from '../data/images';
import { useSEO } from '../hooks/useSEO';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { PageHero } from '../components/PageHero';
import { ParallaxImg } from '../components/ParallaxImg';
import { Reveal, ClipReveal } from '../components/Reveal';
import { People } from '../sections/People';
import { ContactCta } from '../sections/ContactCta';

export default function About() {
  useSEO({
    title: 'Sobre a fazenda',
    description:
      'A Fazenda Nova Piratininga foi fundada em 15 de dezembro de 2010 e atua com pecuária e agricultura em Goiás e Tocantins, com foco em qualidade, produtividade e desenvolvimento regional.',
    path: '/sobre',
    image: images.aboutHero.src,
  });

  return (
    <>
      <PageHero title="Uma história construída sobre a terra." image={images.aboutHero} />

      <Container className="py-24 md:py-40">
        {aboutBlocks.map((b) => (
          <section
            key={b.id}
            id={b.id}
            className="grid scroll-mt-28 gap-6 border-t border-white/[0.09] py-14 md:grid-cols-12 md:gap-10 md:py-24"
          >
            <h2 className="display-md md:col-span-4">{b.title}</h2>
            <Reveal className="md:col-span-7 md:col-start-6">
              {b.paragraphs.map((p, i) => (
                <p key={i} className="lead max-w-2xl">
                  {p}
                </p>
              ))}
            </Reveal>
          </section>
        ))}
      </Container>

      <Container className="pb-24 md:pb-40">
        <ClipReveal>
          <ParallaxImg image={images.aboutFeature} className="aspect-[4/3] md:aspect-[21/9]" />
        </ClipReveal>
      </Container>

      <People />

      <Container className="pb-24 md:pb-40">
        <div className="flex flex-wrap gap-3">
          <Button to="/historia">Ver a linha do tempo</Button>
          <Button to="/sustentabilidade" variant="outline">
            Conheça a sustentabilidade
          </Button>
        </div>
      </Container>

      <ContactCta />
    </>
  );
}
