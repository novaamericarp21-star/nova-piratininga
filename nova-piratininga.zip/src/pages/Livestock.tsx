import { images } from '../data/images';
import { livestockSections } from '../data/content';
import { infrastructureStats, livestockStats, statsReference } from '../data/stats';
import { useSEO } from '../hooks/useSEO';
import { Container } from '../components/Container';
import { StatItem } from '../components/CountUp';
import { PageHero } from '../components/PageHero';
import { ParallaxImg } from '../components/ParallaxImg';
import { ClipReveal } from '../components/Reveal';
import { SectionsWithNav } from '../components/SectionsWithNav';
import { Gallery } from '../sections/Gallery';
import { ContactCta } from '../sections/ContactCta';

export default function Livestock() {
  useSEO({
    title: 'Pecuária',
    description:
      'Pecuária de ciclo completo — cria, recria e engorda — com melhoramento genético das raças Nelore e Angus, um dos maiores programas de IATF do Brasil e rastreabilidade por chip.',
    path: '/pecuaria',
    image: images.livestockHero.src,
  });

  return (
    <>
      <PageHero
        title="Pecuária"
        subtitle="Genética, manejo e tecnologia trabalhando juntos."
        image={images.livestockHero}
      />

      <Container className="py-24 md:py-36">
        <div className="grid grid-cols-2 gap-x-8 gap-y-14 lg:grid-cols-4">
          {livestockStats.map((s) => (
            <StatItem key={s.id} stat={s} />
          ))}
        </div>
        <div className="mt-20 grid grid-cols-1 gap-x-8 gap-y-12 border-t border-white/[0.09] pt-14 sm:grid-cols-3">
          {infrastructureStats.map((s) => (
            <StatItem key={s.id} stat={s} />
          ))}
        </div>
        <p className="mt-12 text-[0.8rem] text-stone">{statsReference}</p>
      </Container>

      <Container>
        <ClipReveal>
          <ParallaxImg image={images.livestockFeature} className="aspect-[4/3] md:aspect-[21/9]" />
        </ClipReveal>
      </Container>

      <SectionsWithNav sections={livestockSections} />
      <Gallery only="Pecuária" title="Pecuária em imagens" compact />
      <ContactCta />
    </>
  );
}
