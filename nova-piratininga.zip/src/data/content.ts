/**
 * Textos institucionais reutilizados nas páginas.
 * Base: conteúdo publicado em novapiratininga.com. Não inclua afirmações sem respaldo oficial.
 */

export const scalePillars = [
  {
    id: 'pecuaria',
    title: 'Pecuária',
    text: 'Ciclo completo de cria, recria e engorda, com aprimoramento das raças Nelore e Angus.',
    href: '/pecuaria',
  },
  {
    id: 'agricultura',
    title: 'Agricultura',
    text: 'Soja e milho em larga escala, com armazenagem própria de grãos.',
    href: '/agricultura',
  },
  {
    id: 'tecnologia',
    title: 'Tecnologia',
    text: 'Agricultura de precisão, identificação por chip e software de gestão do rebanho.',
    href: '#tecnologia',
  },
  {
    id: 'integracao',
    title: 'Integração',
    text: 'Lavoura e pecuária conduzidas de forma integrada e sustentável.',
    href: '#integracao',
  },
];

export type TechIconId = 'precision' | 'herd' | 'tag' | 'pivot' | 'storage' | 'handling' | 'ilp';

export const techItems: Array<{ id: string; icon: TechIconId; title: string; text: string }> = [
  {
    id: 'precisao',
    icon: 'precision',
    title: 'Agricultura de precisão',
    text: 'Investimento robusto em alta tecnologia na lavoura, sustentando o crescimento a cada safra.',
  },
  {
    id: 'gestao',
    icon: 'herd',
    title: 'Gestão do rebanho',
    text: 'Software de gestão que controla a identificação e o acompanhamento dos animais.',
  },
  {
    id: 'identificacao',
    icon: 'tag',
    title: 'Identificação animal',
    text: 'Hoje, 100% do gado tem identificação por chip.',
  },
  {
    id: 'irrigacao',
    icon: 'pivot',
    title: 'Irrigação',
    text: 'Pivôs de irrigação implantados em 2020.',
  },
  {
    id: 'armazenagem',
    icon: 'storage',
    title: 'Armazenagem',
    text: 'Estrutura própria de recepção e armazenagem de grãos, construída em 2019.',
  },
  {
    id: 'manejo',
    icon: 'handling',
    title: 'Manejo',
    text: 'Nutrição de alta qualidade e aplicação rigorosa de protocolos de sanidade.',
  },
  {
    id: 'ilp',
    icon: 'ilp',
    title: 'Integração lavoura-pecuária',
    text: 'Sistemas de ILP conduzidos por uma equipe altamente capacitada.',
  },
];

export const livestockFacts = [
  { label: 'Raças', value: 'Nelore e Angus' },
  { label: 'Ciclo', value: 'Cria, recria e engorda' },
  { label: 'Reprodução', value: 'IATF, inseminação artificial em tempo fixo' },
  { label: 'Rastreabilidade', value: 'Chip em 100% do gado, controlado por software de gestão' },
];

export const agricultureThemes = [
  'Soja',
  'Milho',
  'Agricultura de precisão',
  'Armazenagem',
  'Integração lavoura-pecuária',
];

export const sustainabilityPillars = [
  {
    id: 'preservacao',
    title: 'Preservação',
    text: 'A fazenda mantém extensa área de preservação ambiental (APP) e reserva legal.',
  },
  {
    id: 'integracao',
    title: 'Integração',
    text: 'A integração entre lavoura e pecuária é feita de maneira sustentável, com práticas que, segundo a empresa, ajudam a reduzir a emissão de gases de efeito estufa.',
  },
  {
    id: 'responsabilidade',
    title: 'Responsabilidade',
    text: 'A promoção da responsabilidade socioambiental é um dos pilares da história da Nova Piratininga, ao lado da inovação e do controle de qualidade.',
  },
];

export const peopleBlocks = [
  {
    id: 'desenvolvimento-regional',
    title: 'Desenvolvimento regional',
    year: '2012',
    text: 'A Nova Piratininga contribui para o desenvolvimento econômico das cidades em seu entorno. Em 2012, estruturou a Escola Municipal.',
  },
  {
    id: 'nosso-time',
    title: 'Nosso time',
    year: '2013',
    text: 'Um time de colaboradores qualificado e dedicado. Em 2013, o primeiro Projeto Doma levou educação continuada sobre boas práticas no manejo de animais.',
  },
  {
    id: 'responsabilidade',
    title: 'Responsabilidade',
    year: '2013',
    text: 'Também em 2013, a fazenda criou a Escolinha de Esportes e o clube social para todos os colaboradores e seus familiares.',
  },
];

export type Section = { id: string; title: string; paragraphs: string[] };

export const livestockSections: Section[] = [
  {
    id: 'visao-geral',
    title: 'Visão geral',
    paragraphs: [
      'A Nova Piratininga é reconhecida pelo melhoramento genético e pela fertilidade do rebanho, com o uso de tecnologia de ponta para o aprimoramento das raças Nelore e Angus, e pelos resultados expressivos em qualidade da carne e produtividade do gado.',
      'A fazenda atingiu excelência no ciclo completo, com cria, recria e engorda. São cerca de 120 mil cabeças, das quais 60 mil são matrizes em idade reprodutiva.',
    ],
  },
  {
    id: 'genetica',
    title: 'Genética',
    paragraphs: [
      'O projeto de melhoramento genético começou em 2012, com 4 mil cabeças e uso de IATF. Em 2019, o desenvolvimento genético chegou a 60 mil matrizes bovinas em estação de monta.',
    ],
  },
  {
    id: 'nelore',
    title: 'Nelore',
    paragraphs: ['Uma das duas raças que a fazenda aprimora geneticamente com tecnologia de ponta.'],
  },
  {
    id: 'angus',
    title: 'Angus',
    paragraphs: [
      'A outra raça em aprimoramento genético. A Nova Piratininga está entre as primeiras em número de inseminação da raça Angus.',
    ],
  },
  {
    id: 'ciclo-completo',
    title: 'Cria, recria e engorda',
    paragraphs: [
      'O ciclo completo acontece dentro da propriedade. O confinamento começou em 2013, com capacidade estática para 3 mil cabeças, e em 2020 a capacidade de alojamento passou para 16,5 mil cabeças.',
    ],
  },
  {
    id: 'iatf',
    title: 'IATF',
    paragraphs: [
      'A empresa tem um dos maiores programas de inseminação artificial em tempo fixo (IATF) do Brasil e apresenta elevado índice de prenhez.',
    ],
  },
  {
    id: 'rastreabilidade',
    title: 'Rastreabilidade',
    paragraphs: [
      'A operação adota práticas de excelência para a rastreabilidade do rebanho. Hoje, 100% do gado tem identificação por chip, controlada por software de gestão.',
    ],
  },
  {
    id: 'tecnologia',
    title: 'Tecnologia',
    paragraphs: [
      'Tecnologia de ponta no aprimoramento das raças e software de gestão na identificação do rebanho.',
    ],
  },
  {
    id: 'manejo',
    title: 'Manejo',
    paragraphs: [
      'Uma equipe altamente capacitada conduz o manejo de sistemas de integração lavoura-pecuária (ILP), com nutrição de alta qualidade e aplicação rigorosa de protocolos de sanidade.',
      'Em 2013, o primeiro Projeto Doma iniciou a educação continuada dos colaboradores sobre boas práticas no manejo de animais.',
    ],
  },
];

export const agricultureSections: Section[] = [
  {
    id: 'soja',
    title: 'Soja',
    paragraphs: [
      'A produção de soja começou grande na propriedade: 3 mil hectares plantados na safra 19/20, com o volume dobrando já na safra 20/21.',
      'A área plantada cresce a cada safra. Pelo plano de desenvolvimento divulgado pela empresa, deve chegar a 50 mil hectares nos próximos anos.',
    ],
  },
  {
    id: 'milho',
    title: 'Milho',
    paragraphs: [
      'O plantio de milho começou na safra 20/21, com expectativa de autossuficiência na produção do grão e de forragem (silagem e feno) para o consumo do rebanho.',
    ],
  },
  {
    id: 'agricultura-de-precisao',
    title: 'Agricultura de precisão',
    paragraphs: [
      'Investimentos robustos em alta tecnologia, como a agricultura de precisão, e na capacitação da equipe sustentam o crescimento ano a ano.',
    ],
  },
  {
    id: 'maquinas',
    title: 'Máquinas',
    paragraphs: ['O investimento em máquinas faz parte da estratégia de expansão agrícola da fazenda.'],
  },
  {
    id: 'irrigacao',
    title: 'Irrigação',
    paragraphs: ['Os pivôs de irrigação foram implantados em 2020.'],
  },
  {
    id: 'armazenagem',
    title: 'Armazenagem',
    paragraphs: [
      'A fazenda tem estrutura própria de armazenagem de grãos. Em 2019, construiu uma grande estrutura para recepção e armazenagem.',
    ],
  },
  {
    id: 'ilp',
    title: 'Integração lavoura-pecuária',
    paragraphs: [
      'A integração é o foco da atividade agrícola. Ela começou em 2019, com 3 mil hectares de soja plantada, e segue como base do crescimento sustentável da operação.',
    ],
  },
];

export const aboutBlocks: Section[] = [
  {
    id: 'historia',
    title: 'História',
    paragraphs: [
      'A Nova Piratininga foi fundada em 15 de dezembro de 2010. Sua história é construída com base na dedicação e na eficiência do time, na busca contínua por inovação e controle de qualidade e na promoção da responsabilidade socioambiental.',
    ],
  },
  {
    id: 'proposito',
    title: 'Propósito',
    paragraphs: [
      'Uma empresa do agronegócio brasileiro comprometida com alta qualidade, produtividade e desenvolvimento regional.',
    ],
  },
  {
    id: 'operacao',
    title: 'Operação',
    paragraphs: [
      'Com um dos maiores rebanhos do Brasil, a fazenda se destaca pelo ciclo completo de cria, recria e engorda e por um dos maiores programas de IATF do país. Na lavoura, cultiva soja e milho em larga escala.',
    ],
  },
  {
    id: 'pessoas',
    title: 'Pessoas',
    paragraphs: [
      'Um time de colaboradores qualificado e dedicado, que contribui para o desenvolvimento econômico das cidades no entorno da fazenda.',
    ],
  },
  {
    id: 'tecnologia',
    title: 'Tecnologia',
    paragraphs: [
      'Investimentos em agricultura de precisão, capacitação, máquinas e armazenagem própria de grãos sustentam um crescimento forte ano a ano.',
    ],
  },
  {
    id: 'sustentabilidade',
    title: 'Sustentabilidade',
    paragraphs: [
      'Extensa área de preservação ambiental (APP) e reserva legal, e integração entre lavoura e pecuária conduzida de maneira sustentável.',
    ],
  },
];
