/**
 * TODAS as imagens do site passam por aqui.
 * Para trocar uma foto: altere o caminho (ou aponte para um arquivo em /public) e o alt.
 * As fotos atuais vêm do site antigo e são temporárias.
 *
 * Dica: `npm run images:download` baixa todas para /public/img; depois use VITE_LOCAL_IMAGES=true.
 */

export type ImageAsset = {
  src: string;
  alt: string;
  /** object-position (ex.: '50% 30%') para controlar o recorte */
  position?: string;
  /** versão recortada para telas < 768px */
  mobileSrc?: string;
  srcSet?: string;
};

const REMOTE = 'https://novapiratininga.com/wp-content/uploads';
const useLocal = import.meta.env.VITE_LOCAL_IMAGES === 'true';

const url = (path: string): string => (useLocal ? `/img/${path.split('/').pop()}` : `${REMOTE}/${path}`);

const img = (
  path: string,
  alt: string,
  opts: { position?: string; mobile?: string } = {},
): ImageAsset => ({
  src: url(path),
  alt,
  position: opts.position,
  mobileSrc: opts.mobile ? url(opts.mobile) : undefined,
});

export const images = {
  logo: img('2021/03/logo-footer.png', 'Nova Piratininga'),

  hero: img('2021/04/banner-home.jpg', 'Paisagem da Fazenda Nova Piratininga', { position: '50% 60%' }),
  operation: img('2021/04/fototratada1-1.jpg', 'Operação da Fazenda Nova Piratininga'),
  operationAlt: img('2021/04/fototratada2-1.jpg', 'Área de produção da Fazenda Nova Piratininga'),
  hq: img('2021/04/foto-sede-001-1.jpg', 'Sede da Fazenda Nova Piratininga'),
  cattle: img('2021/04/foto-gado-005-1.jpg', 'Gado na Fazenda Nova Piratininga'),
  cattleAlt: img('2021/04/foto-gado-002-1.jpg', 'Rebanho na Fazenda Nova Piratininga'),
  soy: img('2021/04/foto-soja-004-1.jpg', 'Lavoura de soja na Fazenda Nova Piratininga'),
  water: img('2021/04/foto-agua-003-1.jpg', 'Água e paisagem na Fazenda Nova Piratininga'),
  sunset: img('2021/04/boiadeiros-por-do-sol.png', 'Boiadeiros ao pôr do sol na Fazenda Nova Piratininga'),
  satellite: img('2021/03/satelite-1.png', 'Vista aérea da área da Fazenda Nova Piratininga'),

  livestockHome: img('2021/03/pecuaria.jpg', 'Pecuária na Fazenda Nova Piratininga'),
  agricultureHome: img('2021/03/agricultura-1.jpg', 'Agricultura na Fazenda Nova Piratininga'),

  aboutHero: img('2021/03/topo-sobre.jpg', 'Fazenda Nova Piratininga', { mobile: '2021/03/topo-sobre-mobile.jpg' }),
  aboutFeature: img('2021/03/imagem-sobre.png', 'Operação da Fazenda Nova Piratininga', {
    mobile: '2021/03/imagem-sobre-mobile.jpg',
  }),

  livestockHero: img('2021/04/topo-pecuaria.webp', 'Pecuária da Fazenda Nova Piratininga', {
    mobile: '2021/04/topo-pecuaria-mobile.webp',
  }),
  livestockFeature: img('2021/04/imagem-pecuaria.webp', 'Rebanho da Fazenda Nova Piratininga'),

  agricultureHero: img('2021/04/topo-agricultura.webp', 'Agricultura da Fazenda Nova Piratininga', {
    mobile: '2021/04/topo-agricultura-mobile.webp',
  }),
  agricultureFeature: img('2021/04/imagem-agricultura.webp', 'Lavoura da Fazenda Nova Piratininga'),

  contactHero: img('2021/04/banner-contato.jpg', 'Fazenda Nova Piratininga', {
    mobile: '2021/04/banner-contato-mobile.jpg',
  }),

  history2010: img('2021/04/np_2010.jpg', 'Registro da Nova Piratininga em 2010'),
};

export type GalleryCategory = 'Pecuária' | 'Agricultura' | 'Estrutura' | 'Natureza' | 'Tecnologia';

export type GalleryImage = ImageAsset & { category: GalleryCategory };

const pecuaria = [
  '2021/04/pecuaria-01.webp', '2021/04/pecuaria-02.webp', '2021/04/pecuaria-03.webp',
  '2021/04/pecuaria-04.webp', '2021/04/pecuaria-05.webp', '2021/04/pecuaria-06.webp',
  '2021/04/pecuaria-07.webp', '2021/04/pecuaria-08.webp', '2021/04/pecuaria-09.webp',
  '2021/04/pecuaria-10.webp', '2021/04/pecuaria-11.webp',
];

const agricultura = [
  '2021/04/agricultura-01.webp', '2021/04/agricultura-02.webp', '2021/04/agricultura-03.webp',
  '2021/04/agricultura-04.webp', '2021/04/agricultura-05.webp', '2021/04/agricultura-06.webp',
  '2021/04/agricultura-07.webp', '2021/04/agricultura-08.webp', '2021/04/agricultura-09.webp',
  '2021/04/agricultura-10.webp', '2021/04/agricultura-11.webp',
];

const sobre = [
  '2021/04/sobre-a-fazenda-01.webp', '2021/04/sobre-a-fazenda-02.webp', '2021/04/sobre-a-fazenda-03.webp',
  '2021/04/sobre-a-fazenda-04.webp', '2021/04/sobre-a-fazenda-05.webp', '2021/04/sobre-a-fazenda-06.webp',
  '2021/04/sobre-a-fazenda-07.webp', '2021/04/sobre-a-fazenda-08.webp', '2021/04/sobre-a-fazenda-09.webp',
  '2021/04/sobre-a-fazenda-10.webp',
];

/**
 * MAPEAMENTO TEMPORÁRIO: as fotos "sobre-a-fazenda-XX" do site antigo não têm legenda.
 * Confira as categorias de Estrutura e Natureza ao trocar pelas fotos profissionais.
 * "Tecnologia" fica oculta na galeria enquanto não houver fotos aqui.
 */
export const galleryImages: GalleryImage[] = [
  ...pecuaria.map((p, i) => ({ ...img(p, `Pecuária na Fazenda Nova Piratininga, foto ${i + 1}`), category: 'Pecuária' as const })),
  ...agricultura.map((p, i) => ({ ...img(p, `Agricultura na Fazenda Nova Piratininga, foto ${i + 1}`), category: 'Agricultura' as const })),
  { ...images.hq, category: 'Estrutura' },
  ...sobre.slice(0, 5).map((p, i) => ({ ...img(p, `Estrutura da Fazenda Nova Piratininga, foto ${i + 1}`), category: 'Estrutura' as const })),
  { ...images.water, category: 'Natureza' },
  { ...images.sunset, category: 'Natureza' },
  ...sobre.slice(5).map((p, i) => ({ ...img(p, `Paisagem da Fazenda Nova Piratininga, foto ${i + 1}`), category: 'Natureza' as const })),
];

export const galleryCategories: GalleryCategory[] = ['Pecuária', 'Agricultura', 'Estrutura', 'Natureza', 'Tecnologia'];
