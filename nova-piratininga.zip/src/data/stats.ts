/**
 * Indicadores oficiais. Só entra aqui número que a empresa já divulgou.
 * Fonte: site institucional atual (conteúdo com referência de 2021). Atualize antes de publicar, se houver dado novo.
 */

export type Stat = {
  id: string;
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  label: string;
  note?: string;
};

export const statsReference = 'Dados institucionais divulgados pela empresa (referência: site institucional, 2021).';

export const livestockStats: Stat[] = [
  { id: 'cabecas', value: 120, suffix: ' mil', label: 'cabeças no rebanho', note: 'Valor aproximado' },
  { id: 'matrizes', value: 60, suffix: ' mil', label: 'matrizes em idade reprodutiva' },
  { id: 'chip', value: 100, suffix: '%', label: 'do gado com identificação por chip' },
  {
    id: 'confinamento',
    value: 16.5,
    decimals: 1,
    suffix: ' mil',
    label: 'cabeças de capacidade estática no confinamento',
    note: 'Ampliação de 2020',
  },
];

export const infrastructureStats: Stat[] = [
  { id: 'pastos', value: 1300, label: 'pastos, a partir da divisão de pastagem', note: 'Eram 220 antes de 2011' },
  { id: 'adutora', value: 500, prefix: '+', suffix: ' km', label: 'de adutora para distribuir água pela fazenda' },
  { id: 'bebedouros', value: 650, prefix: '+', label: 'bebedouros de 25 mil litros cada' },
];

export const agricultureStats: Stat[] = [
  {
    id: 'soja',
    value: 3,
    suffix: ' mil ha',
    label: 'de soja plantados na safra 19/20',
    note: 'O volume dobrou na safra 20/21',
  },
];

/** Meta divulgada pela empresa (não é resultado). */
export const soyGoal = { hectares: 50, unit: 'mil hectares', text: 'Plano de desenvolvimento divulgado pela empresa: chegar a 50 mil hectares de soja nos próximos anos.' };

/**
 * Indicadores de sustentabilidade. Vazio de propósito: o site atual não publica números ambientais.
 * Quando a empresa fornecer dados oficiais (ex.: área de preservação), adicione aqui e eles aparecem sozinhos.
 */
export const sustainabilityStats: Stat[] = [];
