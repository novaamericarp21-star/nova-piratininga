/**
 * Fonte única dos dados institucionais.
 * Tudo aqui vem do site atual (novapiratininga.com). Itens marcados com CONFIRMAR
 * precisam de validação da empresa antes da publicação.
 */

export type SocialId = 'facebook' | 'instagram' | 'linkedin' | 'youtube';

export const company = {
  name: 'Fazenda Nova Piratininga',
  shortName: 'Nova Piratininga',
  siteUrl: 'https://novapiratininga.com',
  ogImage: 'https://novapiratininga.com/wp-content/uploads/2021/02/fazenda-nova-piratininga-003.jpg',

  foundedYear: 2010,
  foundedDate: '15 de dezembro de 2010',

  tagline: ['Gera resultados.', 'Respeita a vida.'],
  heroLine: 'Excelência que nasce da terra.',
  heroContext: 'Agropecuária brasileira integrada entre Goiás e Tocantins.',
  description:
    'A Fazenda Nova Piratininga é uma empresa do agronegócio brasileiro, comprometida com alta qualidade, produtividade e desenvolvimento regional.',

  address: {
    line1: 'Estrada Piratininga s/nº, Km 60',
    line2: 'Zona Rural',
    city: 'São Miguel do Araguaia',
    state: 'GO',
    postalCode: '76590-000',
  },
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=' +
    encodeURIComponent('Estrada Piratininga Km 60, São Miguel do Araguaia, GO, 76590-000'),

  municipalities: [
    { name: 'São Miguel do Araguaia', uf: 'GO' },
    { name: 'Araguaçu', uf: 'TO' },
  ],

  phones: [
    { display: '+55 62 3364-6400', href: 'tel:+556233646400' },
    // No site atual este número aponta para o link do primeiro; aqui o link segue o número exibido.
    { display: '+55 62 3364-2548', href: 'tel:+556233642548' },
    { display: '+55 62 3364-3678', href: 'tel:+556233643678' },
  ],

  /** Destino do formulário. Veio de um texto de briefing na página de contato atual. CONFIRMAR. */
  formRecipient: 'contato@novapiratininga.com',

  socials: [
    { id: 'facebook', label: 'Facebook', href: 'https://www.facebook.com/novapiratininga/' },
    { id: 'instagram', label: 'Instagram', href: 'https://www.instagram.com/novapiratininga/' },
    { id: 'linkedin', label: 'LinkedIn', href: 'https://www.linkedin.com/company/novapiratininga' },
    {
      id: 'youtube',
      label: 'YouTube',
      href: 'https://www.youtube.com/channel/UCeYuBOCguVLjWCZYDkPnpPA',
    },
  ] as Array<{ id: SocialId; label: string; href: string }>,
};
