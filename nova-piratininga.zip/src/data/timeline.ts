import { images, type ImageAsset } from './images';

export type TimelineEvent = {
  year: number;
  title: string;
  text: string;
  image?: ImageAsset;
};

/** Marcos publicados no site institucional. Não adicionar eventos sem confirmação da empresa. */
export const timeline: TimelineEvent[] = [
  {
    year: 2010,
    title: 'Fundação',
    text: 'Fundação da Nova Piratininga no dia 15 de dezembro de 2010.',
    image: images.history2010,
  },
  {
    year: 2011,
    title: 'Divisão de pastagem',
    text: 'Implantação da divisão de pastagem, que possibilitou o salto no número de pastos de 220 para 1.300.',
    image: images.cattle,
  },
  {
    year: 2011,
    title: 'Água em toda a fazenda',
    text: 'Distribuição de água em toda a fazenda, com a construção de mais de 500 km de adutora e mais de 650 bebedouros de 25 mil litros cada.',
    image: images.water,
  },
  {
    year: 2012,
    title: 'Melhoramento genético',
    text: 'Início do projeto de melhoramento genético, com 4 mil cabeças e uso de IATF.',
    image: images.cattleAlt,
  },
  {
    year: 2012,
    title: 'Escola Municipal',
    text: 'Estruturação da Escola Municipal.',
  },
  {
    year: 2013,
    title: 'Confinamento',
    text: 'Início do confinamento do gado bovino, com capacidade estática para 3 mil cabeças.',
    image: images.livestockHome,
  },
  {
    year: 2013,
    title: 'Projeto Doma',
    text: 'Primeiro Projeto Doma, voltado à educação continuada dos colaboradores sobre boas práticas no manejo de animais.',
    image: images.sunset,
  },
  {
    year: 2013,
    title: 'Esportes e convivência',
    text: 'Criação da Escolinha de Esportes e do clube social para todos os colaboradores e familiares.',
  },
  {
    year: 2019,
    title: 'Integração lavoura-pecuária',
    text: 'Integração lavoura-pecuária, com 3 mil hectares de soja plantada.',
    image: images.soy,
  },
  {
    year: 2019,
    title: 'Armazenagem de grãos',
    text: 'Construção de grande estrutura para recepção e armazenagem de grãos.',
    image: images.agricultureHome,
  },
  {
    year: 2019,
    title: '60 mil matrizes',
    text: 'Desenvolvimento genético chega a 60 mil matrizes bovinas em estação de monta.',
    image: images.livestockFeature,
  },
  {
    year: 2020,
    title: 'Confinamento ampliado',
    text: 'Aumento da capacidade estática de alojamento do confinamento para 16,5 mil cabeças.',
    image: images.cattle,
  },
  {
    year: 2020,
    title: 'Pivôs de irrigação',
    text: 'Implantação dos pivôs de irrigação.',
    image: images.agricultureFeature,
  },
];
