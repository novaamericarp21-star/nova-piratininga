export type NavItem = { label: string; to: string };

export const nav: NavItem[] = [
  { label: 'Sobre', to: '/sobre' },
  { label: 'Pecuária', to: '/pecuaria' },
  { label: 'Agricultura', to: '/agricultura' },
  { label: 'Sustentabilidade', to: '/sustentabilidade' },
  { label: 'História', to: '/historia' },
  { label: 'Contato', to: '/contato' },
];
