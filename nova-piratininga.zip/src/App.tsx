import { lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';

const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Livestock = lazy(() => import('./pages/Livestock'));
const Agriculture = lazy(() => import('./pages/Agriculture'));
const Sustainability = lazy(() => import('./pages/Sustainability'));
const History = lazy(() => import('./pages/History'));
const Contact = lazy(() => import('./pages/Contact'));
const NotFound = lazy(() => import('./pages/NotFound'));

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="sobre" element={<About />} />
        <Route path="pecuaria" element={<Livestock />} />
        <Route path="agricultura" element={<Agriculture />} />
        <Route path="sustentabilidade" element={<Sustainability />} />
        <Route path="historia" element={<History />} />
        <Route path="contato" element={<Contact />} />
        {/* URL antiga do WordPress */}
        <Route path="sobre-a-fazenda" element={<Navigate to="/sobre" replace />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
