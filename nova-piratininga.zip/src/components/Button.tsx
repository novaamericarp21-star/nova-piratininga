import type { MouseEventHandler, ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/cn';

type Props = {
  children: ReactNode;
  to?: string;
  href?: string;
  external?: boolean;
  onClick?: MouseEventHandler<HTMLElement>;
  type?: 'button' | 'submit';
  disabled?: boolean;
  variant?: 'primary' | 'outline';
  size?: 'sm' | 'md';
  className?: string;
};

const base =
  'inline-flex select-none items-center justify-center rounded-sm text-[0.74rem] font-semibold uppercase tracking-[0.16em] ' +
  'transition-[background-color,border-color,color] duration-200 ease-out disabled:cursor-not-allowed disabled:opacity-60';

const variants = {
  primary: 'bg-bone text-ink-950 hover:bg-white',
  outline: 'border border-white/[0.24] text-bone hover:border-white/55 hover:bg-white/[0.06]',
};

const sizes = {
  sm: 'min-h-11 px-5',
  md: 'min-h-[3.25rem] px-7',
};

export function Button({
  children,
  to,
  href,
  external,
  onClick,
  type = 'button',
  disabled,
  variant = 'primary',
  size = 'md',
  className,
}: Props) {
  const cls = cn(base, variants[variant], sizes[size], className);

  if (to) {
    return (
      <Link to={to} className={cls} onClick={onClick}>
        {children}
      </Link>
    );
  }
  if (href) {
    return (
      <a
        href={href}
        className={cls}
        onClick={onClick}
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      >
        {children}
      </a>
    );
  }
  return (
    <button type={type} className={cls} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}
