import { Facebook, Instagram, Linkedin, Youtube } from 'lucide-react';
import { company, type SocialId } from '../data/company';
import { cn } from '../lib/cn';

const icons: Record<SocialId, typeof Facebook> = {
  facebook: Facebook,
  instagram: Instagram,
  linkedin: Linkedin,
  youtube: Youtube,
};

export function SocialLinks({ className }: { className?: string }) {
  return (
    <ul className={cn('flex items-center gap-1', className)}>
      {company.socials.map((s) => {
        const Icon = icons[s.id];
        return (
          <li key={s.id}>
            <a
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${s.label} da ${company.name}`}
              className="flex h-11 w-11 items-center justify-center text-sand/70 transition-colors duration-200 ease-out hover:text-bone"
            >
              <Icon size={19} strokeWidth={1.4} aria-hidden="true" />
            </a>
          </li>
        );
      })}
    </ul>
  );
}
