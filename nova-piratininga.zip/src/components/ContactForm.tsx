import { useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { Check } from 'lucide-react';
import { company } from '../data/company';
import { cn } from '../lib/cn';
import { Button } from './Button';

type Field = 'nome' | 'email' | 'telefone' | 'assunto' | 'mensagem';
type Values = Record<Field, string> & { site: string };
type Errors = Partial<Record<Field, string>>;
type Status = 'idle' | 'submitting' | 'sent' | 'mailto' | 'error';

const empty: Values = { nome: '', email: '', telefone: '', assunto: '', mensagem: '', site: '' };
const order: Field[] = ['nome', 'email', 'telefone', 'assunto', 'mensagem'];

function validate(v: Values): Errors {
  const e: Errors = {};
  if (v.nome.trim().length < 2) e.nome = 'Informe seu nome.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) e.email = 'Informe um e-mail válido, como nome@empresa.com.';
  if (v.telefone.trim() && v.telefone.replace(/\D/g, '').length < 10) {
    e.telefone = 'Digite o telefone com DDD, por exemplo (62) 99999-9999.';
  }
  if (v.assunto.trim().length < 3) e.assunto = 'Informe o assunto da mensagem.';
  if (v.mensagem.trim().length < 10) e.mensagem = 'Escreva uma mensagem com pelo menos 10 caracteres.';
  return e;
}

const inputBase =
  'block w-full min-h-[3.25rem] border-0 border-b bg-transparent px-0 py-3 text-[1.02rem] text-bone placeholder:text-stone/70 ' +
  'transition-colors duration-200 ease-out focus:outline-none focus-visible:outline-none';

export function ContactForm() {
  const [values, setValues] = useState<Values>(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>('idle');

  const endpoint = import.meta.env.VITE_CONTACT_ENDPOINT;

  const onChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name as Field]) setErrors((er) => ({ ...er, [name]: undefined }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (values.site) return; // campo isca: preenchido por robôs
    const found = validate(values);
    setErrors(found);
    const firstInvalid = order.find((f) => found[f]);
    if (firstInvalid) {
      document.getElementById(`campo-${firstInvalid}`)?.focus();
      return;
    }

    setStatus('submitting');
    try {
      if (endpoint) {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({
            nome: values.nome,
            email: values.email,
            telefone: values.telefone,
            assunto: values.assunto,
            mensagem: values.mensagem,
          }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        setStatus('sent');
      } else {
        const body = `Nome: ${values.nome}\nE-mail: ${values.email}\nTelefone: ${values.telefone || 'não informado'}\n\n${values.mensagem}`;
        window.location.href = `mailto:${company.formRecipient}?subject=${encodeURIComponent(values.assunto)}&body=${encodeURIComponent(body)}`;
        setStatus('mailto');
      }
    } catch {
      setStatus('error');
    }
  };

  const reset = () => {
    setValues(empty);
    setErrors({});
    setStatus('idle');
  };

  if (status === 'sent' || status === 'mailto') {
    return (
      <div role="status" className="border-t border-moss/60 pt-8">
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-moss text-moss">
          <Check size={20} strokeWidth={1.5} aria-hidden="true" />
        </span>
        <h2 className="display-md mt-6">
          {status === 'sent' ? 'Mensagem enviada.' : 'Sua mensagem está pronta.'}
        </h2>
        <p className="body-copy mt-3 max-w-md">
          {status === 'sent'
            ? 'Recebemos seu contato e responderemos pelo e-mail ou telefone informado.'
            : 'Abrimos o seu aplicativo de e-mail com a mensagem preenchida. Falta só enviar por lá.'}
        </p>
        <div className="mt-8">
          <Button variant="outline" onClick={reset}>
            Enviar outra mensagem
          </Button>
        </div>
      </div>
    );
  }

  const field = (name: Field, label: string, props: { type?: string; autoComplete?: string; optional?: boolean } = {}) => {
    const err = errors[name];
    return (
      <div>
        <label htmlFor={`campo-${name}`} className="text-[0.85rem] font-semibold text-sand">
          {label}
          {props.optional && <span className="ml-2 font-normal text-stone">opcional</span>}
        </label>
        <input
          id={`campo-${name}`}
          name={name}
          type={props.type ?? 'text'}
          autoComplete={props.autoComplete}
          value={values[name]}
          onChange={onChange}
          aria-invalid={err ? true : undefined}
          aria-describedby={err ? `erro-${name}` : undefined}
          className={cn(inputBase, err ? 'border-red-300/80' : 'border-white/[0.22] focus:border-moss')}
        />
        {err && (
          <p id={`erro-${name}`} className="mt-2 text-[0.85rem] text-red-300">
            {err}
          </p>
        )}
      </div>
    );
  };

  const msgErr = errors.mensagem;

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-8">
      <div className="grid gap-8 sm:grid-cols-2">
        {field('nome', 'Nome', { autoComplete: 'name' })}
        {field('email', 'E-mail', { type: 'email', autoComplete: 'email' })}
      </div>
      <div className="grid gap-8 sm:grid-cols-2">
        {field('telefone', 'Telefone', { type: 'tel', autoComplete: 'tel', optional: true })}
        {field('assunto', 'Assunto')}
      </div>

      <div>
        <label htmlFor="campo-mensagem" className="text-[0.85rem] font-semibold text-sand">
          Mensagem
        </label>
        <textarea
          id="campo-mensagem"
          name="mensagem"
          rows={5}
          value={values.mensagem}
          onChange={onChange}
          aria-invalid={msgErr ? true : undefined}
          aria-describedby={msgErr ? 'erro-mensagem' : undefined}
          className={cn(inputBase, 'resize-y', msgErr ? 'border-red-300/80' : 'border-white/[0.22] focus:border-moss')}
        />
        {msgErr && (
          <p id="erro-mensagem" className="mt-2 text-[0.85rem] text-red-300">
            {msgErr}
          </p>
        )}
      </div>

      {/* Campo isca: escondido para pessoas */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label htmlFor="campo-site">Não preencha</label>
        <input id="campo-site" name="site" tabIndex={-1} autoComplete="off" value={values.site} onChange={onChange} />
      </div>

      {status === 'error' && (
        <p role="alert" className="border-l-2 border-red-300 pl-4 text-[0.95rem] text-red-200">
          Não foi possível enviar agora. Tente novamente em instantes ou ligue para {company.phones[0].display}.
        </p>
      )}

      <Button type="submit" disabled={status === 'submitting'} className="w-full sm:w-auto">
        {status === 'submitting' ? 'Enviando…' : 'Enviar mensagem'}
      </Button>
    </form>
  );
}
