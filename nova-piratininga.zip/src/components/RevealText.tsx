import { Fragment } from 'react';
import type { ElementType } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { EASE_OUT } from '../lib/motion';

type Props = {
  text: string;
  as?: 'h1' | 'h2' | 'h3' | 'p' | 'div';
  className?: string;
  delay?: number;
  stagger?: number;
  /** 'mount' anima ao carregar (hero); 'view' anima ao entrar na tela. */
  trigger?: 'mount' | 'view';
};

/**
 * Título que sobe palavra por palavra por trás de uma máscara.
 * Use "\n" no texto para forçar quebra de linha.
 */
export function RevealText({ text, as = 'h2', className, delay = 0, stagger = 0.045, trigger = 'view' }: Props) {
  const reduce = useReducedMotion();
  const Tag = as as ElementType;
  const plain = text.replace(/\n/g, ' ');

  if (reduce) {
    return (
      <Tag className={className}>
        {text.split('\n').map((line, i, all) => (
          <Fragment key={i}>
            {line}
            {i < all.length - 1 && <br />}
          </Fragment>
        ))}
      </Tag>
    );
  }

  const anim =
    trigger === 'mount'
      ? { animate: { y: '0%' } }
      : { whileInView: { y: '0%' }, viewport: { once: true, margin: '0px 0px -12% 0px' } };

  let index = 0;
  return (
    <Tag className={className} aria-label={plain}>
      {text.split('\n').map((line, li) => (
        <span key={li} className="block" aria-hidden="true">
          {line.split(' ').map((word, wi, words) => {
            const i = index++;
            return (
              <span
                key={`${word}-${wi}`}
                className="inline-block overflow-hidden align-bottom"
                style={{ paddingTop: '0.14em', marginTop: '-0.14em', paddingBottom: '0.1em', marginBottom: '-0.1em' }}
              >
                <motion.span
                  className="inline-block"
                  initial={{ y: '112%' }}
                  {...anim}
                  transition={{ duration: 0.7, delay: delay + i * stagger, ease: EASE_OUT }}
                >
                  {word}
                  {wi < words.length - 1 ? '\u00A0' : ''}
                </motion.span>
              </span>
            );
          })}
        </span>
      ))}
    </Tag>
  );
}
