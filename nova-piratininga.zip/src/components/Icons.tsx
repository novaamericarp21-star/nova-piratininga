import type { SVGProps } from 'react';
import type { TechIconId } from '../data/content';

type P = SVGProps<SVGSVGElement>;

const common = {
  viewBox: '0 0 32 32',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.25,
  strokeLinecap: 'square' as const,
  strokeLinejoin: 'miter' as const,
  'aria-hidden': true,
  focusable: false,
};

/** Mira sobre grade: agricultura de precisão */
const Precision = (p: P) => (
  <svg {...common} {...p}>
    <circle cx="16" cy="16" r="6.5" />
    <path d="M16 3v7M16 22v7M3 16h7M22 16h7" />
    <circle cx="16" cy="16" r="0.9" fill="currentColor" />
  </svg>
);

/** Eixos e colunas: gestão do rebanho */
const Herd = (p: P) => (
  <svg {...common} {...p}>
    <path d="M5 4v23h22" />
    <path d="M10 22v-5M15 22v-10M20 22v-7M25 22V9" />
  </svg>
);

/** Chip: identificação animal */
const Tag = (p: P) => (
  <svg {...common} {...p}>
    <rect x="8" y="8" width="16" height="16" />
    <rect x="13" y="13" width="6" height="6" />
    <path d="M12 4v4M16 4v4M20 4v4M12 24v4M16 24v4M20 24v4M4 12h4M4 16h4M4 20h4M24 12h4M24 16h4M24 20h4" />
  </svg>
);

/** Pivô central: irrigação */
const Pivot = (p: P) => (
  <svg {...common} {...p}>
    <circle cx="16" cy="16" r="12" strokeDasharray="2 3" />
    <path d="M16 16L26 8" />
    <circle cx="16" cy="16" r="2" />
    <path d="M6 29h20" />
  </svg>
);

/** Silos: armazenagem */
const Storage = (p: P) => (
  <svg {...common} {...p}>
    <path d="M5 27V11a5 4 0 0 1 10 0v16M17 27V11a5 4 0 0 1 10 0v16" />
    <path d="M5 17h10M17 17h10M3 27h26" />
  </svg>
);

/** Checklist: manejo e protocolos */
const Handling = (p: P) => (
  <svg {...common} {...p}>
    <path d="M8 5h16v22H8z" />
    <path d="M12 12l2 2 4-4M12 20h8" />
  </svg>
);

/** Dois círculos que se cruzam: integração */
const Ilp = (p: P) => (
  <svg {...common} {...p}>
    <circle cx="12" cy="16" r="8" />
    <circle cx="20" cy="16" r="8" />
  </svg>
);

const map: Record<TechIconId, (p: P) => JSX.Element> = {
  precision: Precision,
  herd: Herd,
  tag: Tag,
  pivot: Pivot,
  storage: Storage,
  handling: Handling,
  ilp: Ilp,
};

export function TechIcon({ id, ...rest }: { id: TechIconId } & P) {
  const Cmp = map[id];
  return <Cmp {...rest} />;
}
