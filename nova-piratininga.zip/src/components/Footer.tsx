import { Link } from 'react-router-dom';
import { Phone, MapPin } from 'lucide-react';
import { company } from '../data/company';
import { nav } from '../data/navigation';
import { Container } from './Container';
import { Logo } from './Logo';
import { SocialLinks } from './Social';
import { TopoLines } from './TopoLines';

export function Footer() {
  const { address } = company;
  return (
    <footer className="relative isolate overflow-hidden border-t border-white/[0.06] bg-ink-900">
      <TopoLines
        className="pointer-events-none absolute inset-0 -z-10 h-full w-full text-forest-600/[0.16]"
        cx={820}
        cy={620}
        rings={16}
        step={38}
        seed={2.4}
      />
      <Container className="pb-10 pt-24 md:pt-32">
        <p className="display-xl uppercase" style={{ fontSize: 'clamp(2.1rem, 7vw, 7rem)', lineHeight: 0.98 }}>
          {company.tagline[0]}
          <br />
          {company.tagline[1]}
        </p>

        <div className="mt-20 grid gap-14 md:grid-cols-12 md:gap-8">
          <div className="md:col-span-5">
            <Link to="/" aria-label={`${company.name}, página inicial`} className="inline-block">
              <Logo className="h-11 md:h-12" />
            </Link>
            <p className="body-copy mt-6 max-w-sm">{company.description}</p>
          </div>

          <nav aria-label="Rodapé" className="md:col-span-3 md:col-start-7">
            <p className="label-caps text-stone">Navegar</p>
            <ul className="mt-5 space-y-1">
              {[{ label: 'Início', to: '/' }, ...nav].map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="link-line inline-flex min-h-9 items-center text-sand/85 transition-colors hover:text-bone"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="md:col-span-3">
            <p className="label-caps text-stone">Contato</p>
            <address className="mt-5 space-y-5 not-italic text-sand/85">
              <p className="flex gap-3">
                <MapPin size={18} strokeWidth={1.4} className="mt-1 shrink-0 text-moss" aria-hidden="true" />
                <span>
                  {address.city} – {address.state}
                  <br />
                  {address.line1}
                  <br />
                  {address.line2} · CEP {address.postalCode}
                </span>
              </p>
              <div className="flex gap-3">
                <Phone size={18} strokeWidth={1.4} className="mt-2.5 shrink-0 text-moss" aria-hidden="true" />
                <ul>
                  {company.phones.map((p) => (
                    <li key={p.href}>
                      <a href={p.href} className="link-line inline-flex min-h-9 items-center transition-colors hover:text-bone">
                        {p.display}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </address>
            <SocialLinks className="-ml-3 mt-4" />
          </div>
        </div>

        <div className="mt-20 flex flex-col gap-2 border-t border-white/[0.08] pt-6 text-[0.85rem] text-stone md:flex-row md:justify-between">
          <p>
            © {new Date().getFullYear()} {company.name}. Todos os direitos reservados.
          </p>
          <p>{company.address.city}, Goiás · Brasil</p>
        </div>
      </Container>
    </footer>
  );
}
