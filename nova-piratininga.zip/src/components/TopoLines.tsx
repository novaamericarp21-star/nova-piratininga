import { useMemo } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { EASE_OUT } from '../lib/motion';

function ring(cx: number, cy: number, r: number, seed: number, wobble: number, squash: number, points = 96): string {
  let d = '';
  for (let i = 0; i <= points; i++) {
    const a = (i / points) * Math.PI * 2;
    const n =
      Math.sin(a * 3 + seed) * 0.5 + Math.sin(a * 5 + seed * 1.7) * 0.3 + Math.sin(a * 2 - seed * 0.6) * 0.2;
    const rr = r * (1 + wobble * n);
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr * squash;
    d += `${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)} `;
  }
  return d + 'Z';
}

type Props = {
  className?: string;
  rings?: number;
  step?: number;
  cx?: number;
  cy?: number;
  seed?: number;
  wobble?: number;
  /** Desenha as curvas ao entrar na tela. */
  animate?: boolean;
};

/** Curvas de nível abstratas (inspiração topográfica). Puramente decorativas. */
export function TopoLines({
  className,
  rings = 14,
  step = 34,
  cx = 500,
  cy = 400,
  seed = 1.3,
  wobble = 0.16,
  animate = false,
}: Props) {
  const reduce = useReducedMotion();
  const paths = useMemo(
    () =>
      Array.from({ length: rings }, (_, k) =>
        ring(cx, cy, 40 + k * step, seed + k * 0.11, wobble * (0.6 + k / rings), 0.78),
      ),
    [rings, step, cx, cy, seed, wobble],
  );

  return (
    <svg
      viewBox="0 0 1000 800"
      preserveAspectRatio="xMidYMid slice"
      className={className}
      aria-hidden="true"
      focusable="false"
      fill="none"
      stroke="currentColor"
    >
      {paths.map((d, i) =>
        animate && !reduce ? (
          <motion.path
            key={i}
            d={d}
            strokeWidth={1}
            vectorEffect="non-scaling-stroke"
            strokeOpacity={0.35 + (i % 3) * 0.12}
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            viewport={{ once: true, margin: '-10%' }}
            transition={{ duration: 1.4, delay: i * 0.05, ease: EASE_OUT }}
          />
        ) : (
          <path
            key={i}
            d={d}
            strokeWidth={1}
            vectorEffect="non-scaling-stroke"
            strokeOpacity={0.35 + (i % 3) * 0.12}
          />
        ),
      )}
    </svg>
  );
}
