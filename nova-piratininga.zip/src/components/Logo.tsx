import { useState } from 'react';
import { images } from '../data/images';
import { company } from '../data/company';
import { cn } from '../lib/cn';

/** Logo oficial (slot em data/images.ts). Se a imagem falhar, cai para o nome em texto. */
export function Logo({ className }: { className?: string }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <span className={cn('font-display text-lg font-light uppercase tracking-[0.08em] text-bone', className)}>
        {company.shortName}
      </span>
    );
  }
  return (
    <img
      src={images.logo.src}
      alt={company.name}
      onError={() => setFailed(true)}
      className={cn('w-auto', className ?? 'h-9 md:h-10')}
      decoding="async"
    />
  );
}
