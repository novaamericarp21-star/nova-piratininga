import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react';
import type { ImageAsset } from '../data/images';
import { Container } from './Container';
import { Img } from './Img';
import { RevealText } from './RevealText';
import { cn } from '../lib/cn';

type Props = {
  title: string;
  subtitle?: string;
  image: ImageAsset;
  /** Título em caixa alta (padrão) ou como escrito. */
  upper?: boolean;
  className?: string;
};

/** Hero das páginas internas: foto em tela cheia, granulação e título grande. */
export function PageHero({ title, subtitle, image, upper = true, className }: Props) {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '13%']);

  return (
    <section ref={ref} className={cn('grain relative isolate flex items-end overflow-hidden', className ?? 'min-h-[78svh]')}>
      <motion.div
        className="absolute inset-x-0 -top-[15%] -z-10 h-[115%]"
        style={reduce ? undefined : { y }}
      >
        <div className="kenburns absolute inset-0">
          <Img image={image} priority className="h-full w-full" />
        </div>
      </motion.div>
      <div className="hero-scrim absolute inset-0 -z-10" />
      <div className="hero-light absolute inset-0 -z-10" />

      <Container className="relative z-10 pb-14 pt-40 md:pb-20">
        <RevealText
          as="h1"
          trigger="mount"
          delay={0.1}
          text={title}
          className={cn('display-xl max-w-[16ch]', upper && 'uppercase')}
        />
        {subtitle && (
          <p className="lead mt-6 max-w-xl">{subtitle}</p>
        )}
      </Container>
    </section>
  );
}
