import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { Phone } from 'lucide-react';
import { nav } from '../data/navigation';
import { company } from '../data/company';
import { EASE_OUT } from '../lib/motion';
import { cn } from '../lib/cn';
import { Logo } from './Logo';
import { Button } from './Button';
import { SocialLinks } from './Social';

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const reduce = useReducedMotion();
  const toggleRef = useRef<HTMLButtonElement>(null);
  const firstLinkRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    const t = window.setTimeout(() => firstLinkRef.current?.focus(), 80);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('keydown', onKey);
      window.clearTimeout(t);
    };
  }, [open]);

  const solid = scrolled && !open;
  const mobileItems = [{ label: 'Início', to: '/' }, ...nav];

  return (
    <>
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 border-b transition-[background-color,border-color,backdrop-filter] duration-300 ease-out',
          solid ? 'border-white/[0.07] bg-ink-950/70 backdrop-blur-xl' : 'border-transparent bg-transparent',
        )}
      >
        <div className="mx-auto flex h-[72px] w-full max-w-[1600px] items-center justify-between px-5 sm:px-8 lg:px-12 xl:px-16">
          <Link
            to="/"
            aria-label={`${company.name}, página inicial`}
            className="origin-left transition-transform duration-300 ease-out"
            style={{ transform: scrolled ? 'scale(0.86)' : 'scale(1)' }}
          >
            <Logo />
          </Link>

          <nav aria-label="Principal" className="hidden items-center gap-8 lg:flex xl:gap-10">
            {nav.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    'link-line label-caps py-2 text-[0.72rem] transition-colors',
                    isActive ? 'text-bone' : 'text-sand/75 hover:text-bone',
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden xl:block">
              <Button to="/sobre" variant="outline" size="sm">
                Conheça nossa operação
              </Button>
            </div>
            <button
              ref={toggleRef}
              type="button"
              aria-expanded={open}
              aria-controls="menu-mobile"
              aria-label={open ? 'Fechar menu' : 'Abrir menu'}
              onClick={() => setOpen((o) => !o)}
              className="relative -mr-2 flex h-12 w-12 items-center justify-center lg:hidden"
            >
              <span
                className={cn(
                  'absolute block h-px w-7 bg-bone transition-transform duration-300 ease-out',
                  open ? 'translate-y-0 rotate-45' : '-translate-y-[5px]',
                )}
              />
              <span
                className={cn(
                  'absolute block h-px w-7 bg-bone transition-transform duration-300 ease-out',
                  open ? 'translate-y-0 -rotate-45' : 'translate-y-[5px]',
                )}
              />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="menu-mobile"
            role="dialog"
            aria-modal="true"
            aria-label="Menu principal"
            className="fixed inset-0 z-40 flex flex-col overflow-y-auto bg-ink-950 px-5 pb-8 pt-24 sm:px-8 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduce ? 0 : 0.25, ease: EASE_OUT }}
          >
            <nav aria-label="Menu móvel" className="flex-1">
              <ul>
                {mobileItems.map((item, i) => (
                  <motion.li
                    key={item.to}
                    initial={reduce ? false : { opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.35, delay: 0.06 + i * 0.04, ease: EASE_OUT }}
                  >
                    <Link
                      ref={i === 0 ? firstLinkRef : undefined}
                      to={item.to}
                      className={cn(
                        'block border-b border-white/[0.08] py-4 font-display text-[clamp(1.75rem,8vw,2.4rem)] font-light',
                        pathname === item.to ? 'text-moss' : 'text-bone',
                      )}
                    >
                      {item.label}
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </nav>
            <div className="mt-8 flex flex-col gap-5">
              <a
                href={company.phones[0].href}
                className="inline-flex min-h-11 items-center gap-3 text-sand/85 transition-colors duration-200 ease-out hover:text-bone"
              >
                <Phone size={18} strokeWidth={1.4} aria-hidden="true" />
                {company.phones[0].display}
              </a>
              <SocialLinks className="-ml-3" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
