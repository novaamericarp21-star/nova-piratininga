import { useEffect, useMemo, useRef, useState } from 'react';
import { animate, useInView, useReducedMotion } from 'motion/react';
import { EASE_OUT } from '../lib/motion';
import { cn } from '../lib/cn';
import type { Stat } from '../data/stats';

type Props = {
  value: number;
  decimals?: number;
  prefix?: string;
  className?: string;
};

/** Número que sobe ao entrar na tela. O valor final fica disponível para leitores de tela. */
export function CountUp({ value, decimals = 0, prefix = '', className }: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -10% 0px' });
  const reduce = useReducedMotion();
  const fmt = useMemo(
    () => new Intl.NumberFormat('pt-BR', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }),
    [decimals],
  );
  const [text, setText] = useState(() => fmt.format(reduce ? value : 0));

  useEffect(() => {
    if (!inView) return;
    if (reduce) {
      setText(fmt.format(value));
      return;
    }
    const controls = animate(0, value, {
      duration: 1.6,
      ease: EASE_OUT,
      onUpdate: (v) => setText(fmt.format(v)),
    });
    return () => controls.stop();
  }, [inView, value, reduce, fmt]);

  return (
    <span ref={ref} className={cn('tabular-nums', className)}>
      <span aria-hidden="true">
        {prefix}
        {text}
      </span>
      <span className="sr-only">
        {prefix}
        {fmt.format(value)}
      </span>
    </span>
  );
}

/** Indicador: número grande e leve + rótulo pequeno. */
export function StatItem({ stat, className }: { stat: Stat; className?: string }) {
  const bigSuffix = stat.suffix === '%';
  return (
    <div className={cn('flex flex-col gap-3', className)}>
      <p className="font-display font-light leading-none tracking-[-0.02em] text-bone text-[clamp(2.8rem,6vw,5.5rem)]">
        <CountUp value={stat.value} decimals={stat.decimals} prefix={stat.prefix} />
        {stat.suffix && (
          <span className={bigSuffix ? '' : 'ml-1 align-baseline text-[0.36em] font-normal text-stone'}>{stat.suffix}</span>
        )}
      </p>
      <p className="max-w-[22ch] text-[0.95rem] leading-snug text-sand/85">{stat.label}</p>
      {stat.note && <p className="text-[0.8rem] leading-snug text-stone">{stat.note}</p>}
    </div>
  );
}
