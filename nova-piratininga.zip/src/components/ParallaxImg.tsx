import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react';
import type { ImageAsset } from '../data/images';
import { cn } from '../lib/cn';
import { Img } from './Img';

type Props = {
  image: ImageAsset;
  className?: string;
  priority?: boolean;
  /** Deslocamento máximo em % (padrão 7). Mantenha discreto. */
  amount?: number;
};

/** Parallax suave: a imagem é ampliada 18% e desliza ±amount%, sem revelar bordas. */
export function ParallaxImg({ image, className, priority, amount = 7 }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const positioned = /\b(absolute|fixed|sticky|relative)\b/.test(className ?? '');
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [`-${amount}%`, `${amount}%`]);

  return (
    <div ref={ref} className={cn(!positioned && 'relative', 'overflow-hidden bg-ink-800', className)}>
      <motion.div className="absolute inset-0" style={reduce ? undefined : { y, scale: 1.18 }}>
        <Img image={image} priority={priority} className="h-full w-full" />
      </motion.div>
    </div>
  );
}
