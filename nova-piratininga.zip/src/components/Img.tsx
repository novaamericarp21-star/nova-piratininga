import { useEffect, useRef, useState } from 'react';
import type { ImageAsset } from '../data/images';
import { cn } from '../lib/cn';

type Props = {
  image: ImageAsset;
  /** Classes do contêiner. Ele precisa ter dimensão (aspect-ratio, h-*, absolute inset-0...). */
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  sizes?: string;
};

/** Imagem com lazy loading, recorte por object-position, versão mobile e fade-in ao carregar. */
export function Img({ image, className, imgClassName, priority, sizes }: Props) {
  const ref = useRef<HTMLImageElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (el && el.complete && el.naturalWidth > 0) setLoaded(true);
  }, []);

  // React 18 não reconhece fetchPriority; o atributo em minúsculas passa direto para o DOM.
  const priorityAttr = { fetchpriority: priority ? 'high' : 'auto' } as Record<string, string>;

  const el = (
    <img
      ref={ref}
      src={image.src}
      srcSet={image.srcSet}
      sizes={image.srcSet ? sizes ?? '100vw' : undefined}
      alt={image.alt}
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      onLoad={() => setLoaded(true)}
      onError={() => setFailed(true)}
      style={{ objectPosition: image.position }}
      className={cn(
        'h-full w-full object-cover transition-opacity duration-500 ease-out',
        loaded && !failed ? 'opacity-100' : 'opacity-0',
        imgClassName,
      )}
      {...priorityAttr}
    />
  );

  const positioned = /\b(absolute|fixed|sticky|relative)\b/.test(className ?? '');

  return (
    <div className={cn(!positioned && 'relative', 'overflow-hidden bg-ink-800', className)}>
      {image.mobileSrc ? (
        <picture>
          <source media="(max-width: 767px)" srcSet={image.mobileSrc} />
          {el}
        </picture>
      ) : (
        el
      )}
    </div>
  );
}
