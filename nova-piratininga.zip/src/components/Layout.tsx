import { Suspense, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Header } from './Header';
import { Footer } from './Footer';

export function Layout() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      // A página pode ainda estar carregando (lazy); tenta por alguns quadros.
      const id = decodeURIComponent(hash.slice(1));
      let tries = 0;
      let raf = 0;
      const seek = () => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView();
        else if (tries++ < 40) raf = requestAnimationFrame(seek);
      };
      raf = requestAnimationFrame(seek);
      return () => cancelAnimationFrame(raf);
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname, hash]);

  return (
    <>
      <a
        href="#conteudo"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-bone focus:px-4 focus:py-3 focus:text-sm focus:font-semibold focus:text-ink-950"
      >
        Ir para o conteúdo
      </a>
      <Header />
      <main id="conteudo" tabIndex={-1} key={pathname} className="page-enter outline-none">
        <Suspense fallback={<div className="min-h-[100svh] bg-ink-950" />}>
          <Outlet />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
