import type { ReactNode } from 'react';
import type { Section } from '../data/content';
import { Container } from './Container';
import { Reveal } from './Reveal';

/** Índice lateral fixo (desktop) + seções de conteúdo. Usado nas páginas de Pecuária e Agricultura. */
export function SectionsWithNav({ sections, aside }: { sections: Section[]; aside?: ReactNode }) {
  return (
    <Container className="py-24 md:py-36">
      <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
        <nav aria-label="Nesta página" className="hidden lg:col-span-3 lg:block">
          <ul className="sticky top-32 border-l border-white/[0.1]">
            {sections.map((s) => (
              <li key={s.id}>
                <a
                  href={`#${s.id}`}
                  className="block min-h-9 py-2 pl-5 text-[0.95rem] text-stone transition-colors duration-200 ease-out hover:text-bone"
                >
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-9">
          {aside}
          {sections.map((s) => (
            <section
              key={s.id}
              id={s.id}
              className="scroll-mt-28 border-t border-white/[0.09] py-12 first:border-t-0 first:pt-0 md:py-16"
            >
              <Reveal>
                <h2 className="display-md">{s.title}</h2>
                <div className="mt-6 max-w-2xl space-y-5">
                  {s.paragraphs.map((p, i) => (
                    <p key={i} className={i === 0 ? 'lead' : 'body-copy'}>
                      {p}
                    </p>
                  ))}
                </div>
              </Reveal>
            </section>
          ))}
        </div>
      </div>
    </Container>
  );
}
