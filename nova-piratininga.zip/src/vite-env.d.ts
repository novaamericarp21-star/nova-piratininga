/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_CONTACT_ENDPOINT?: string;
  readonly VITE_LOCAL_IMAGES?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
