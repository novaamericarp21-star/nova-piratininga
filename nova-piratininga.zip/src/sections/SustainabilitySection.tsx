import { images } from '../data/images';
import { sustainabilityPillars } from '../data/content';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { ParallaxImg } from '../components/ParallaxImg';
import { RevealText } from '../components/RevealText';

export function SustainabilitySection() {
  return (
    <section id="sustentabilidade" className="relative isolate flex min-h-[92svh] scroll-mt-16 items-end overflow-hidden">
      <ParallaxImg image={images.water} className="absolute inset-0 -z-10" amount={6} />
      <div className="absolute inset-0 -z-10 bg-ink-950/45" />
      <div className="scrim-bottom absolute inset-0 -z-10" />

      <Container className="w-full py-20 md:py-28">
        <RevealText as="h2" className="display-xl max-w-[14ch] uppercase" text={'Produzir.\nPreservar.\nEvoluir.'} />

        <ul className="mt-14 grid gap-10 md:mt-20 md:grid-cols-3 md:gap-12">
          {sustainabilityPillars.map((p) => (
            <li key={p.id} className="border-t border-white/[0.22] pt-6">
              <h3 className="font-display text-[1.6rem] font-light text-bone">{p.title}</h3>
              <p className="mt-3 max-w-sm text-[0.98rem] leading-relaxed text-sand/85">{p.text}</p>
            </li>
          ))}
        </ul>

        <div className="mt-12">
          <Button to="/sustentabilidade" variant="outline">
            Conheça nossa atuação
          </Button>
        </div>
      </Container>
    </section>
  );
}
