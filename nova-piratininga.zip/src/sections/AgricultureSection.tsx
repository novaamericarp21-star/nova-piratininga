import { images } from '../data/images';
import { agricultureThemes } from '../data/content';
import { agricultureStats } from '../data/stats';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { StatItem } from '../components/CountUp';
import { ParallaxImg } from '../components/ParallaxImg';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';

export function AgricultureSection() {
  return (
    <section id="agricultura" className="relative scroll-mt-16 overflow-hidden bg-forest-900/45 py-24 md:py-40">
      <Container>
        <RevealText as="h2" className="display-xl uppercase" text="Agricultura" />

        <div className="mt-14 grid gap-14 lg:mt-20 lg:grid-cols-12 lg:gap-20">
          <div className="order-2 lg:order-1 lg:col-span-6">
            <Reveal>
              <p className="lead max-w-lg">
                A tecnologia encontra a terra para transformar produtividade em resultado.
              </p>
            </Reveal>

            <ul className="mt-10 border-t border-white/[0.12]">
              {agricultureThemes.map((t) => (
                <li
                  key={t}
                  className="border-b border-white/[0.12] py-4 font-display text-[clamp(1.35rem,2.2vw,1.9rem)] font-light text-bone"
                >
                  {t}
                </li>
              ))}
            </ul>

            <div className="mt-12 flex flex-wrap items-end gap-x-14 gap-y-8">
              {agricultureStats.slice(0, 1).map((s) => (
                <StatItem key={s.id} stat={s} />
              ))}
            </div>

            <div className="mt-12">
              <Button to="/agricultura" variant="outline">
                Conheça a agricultura
              </Button>
            </div>
          </div>

          <div className="order-1 lg:order-2 lg:col-span-6 lg:-mt-36">
            <ParallaxImg image={images.soy} className="aspect-[4/5]" amount={6} />
          </div>
        </div>
      </Container>
    </section>
  );
}
