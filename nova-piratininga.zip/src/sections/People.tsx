import { peopleBlocks } from '../data/content';
import type { ImageAsset } from '../data/images';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';
import { cn } from '../lib/cn';

/** Fotos das pessoas: preencha quando houver imagens autorizadas. Sem imagem, o bloco fica só com texto. */
const peopleImages: Partial<Record<string, ImageAsset>> = {
  // 'nosso-time': { src: '/img/time.jpg', alt: 'Equipe da Nova Piratininga' },
};

const offsets = ['', 'md:mt-16', 'md:mt-32'];

export function People() {
  return (
    <section className="relative py-24 md:py-40">
      <Container>
        <div className="max-w-2xl">
          <RevealText as="h2" className="display-lg" text="Pessoas que sustentam a operação." />
          <Reveal className="mt-6" delay={0.1}>
            <p className="lead">
              Um time de colaboradores qualificado e dedicado, e iniciativas que chegam às cidades do entorno.
            </p>
          </Reveal>
        </div>

        <div className="mt-16 grid gap-14 md:grid-cols-3 md:gap-10 lg:gap-16">
          {peopleBlocks.map((b, i) => {
            const image = peopleImages[b.id];
            return (
              <Reveal key={b.id} delay={i * 0.08} className={cn(offsets[i])}>
                {image && <Img image={image} className="mb-8 aspect-[4/5]" />}
                <p className="font-display text-[clamp(3.5rem,7vw,6.5rem)] font-light leading-none tracking-[-0.03em] text-forest-600/80">
                  {b.year}
                </p>
                <h3 className="mt-5 font-display text-[1.6rem] font-light text-bone">{b.title}</h3>
                <p className="body-copy mt-3 max-w-sm">{b.text}</p>
              </Reveal>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
