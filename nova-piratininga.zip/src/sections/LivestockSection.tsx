import { images } from '../data/images';
import { livestockFacts } from '../data/content';
import { livestockStats, statsReference } from '../data/stats';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { StatItem } from '../components/CountUp';
import { ParallaxImg } from '../components/ParallaxImg';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';

export function LivestockSection() {
  return (
    <section id="pecuaria" className="relative scroll-mt-16 bg-ink-900 pb-24 md:pb-40">
      <div className="relative">
        <ParallaxImg image={images.livestockHome} className="h-[72svh] min-h-[440px]" />
        <div className="scrim-bottom pointer-events-none absolute inset-0" />
      </div>

      <Container>
        {/* O título invade a base da foto */}
        <RevealText
          as="h2"
          className="display-xxl relative z-10 -mt-[0.5em] uppercase"
          text="Pecuária"
        />

        <div className="mt-14 grid gap-14 lg:mt-20 lg:grid-cols-12 lg:gap-20">
          <div className="lg:col-span-5">
            <Reveal>
              <p className="font-display text-[clamp(1.5rem,2.4vw,2.2rem)] font-light leading-snug text-bone">
                Genética, manejo e tecnologia trabalhando juntos.
              </p>
              <p className="body-copy mt-6 max-w-md">
                A Nova Piratininga é reconhecida pelo melhoramento genético e pela fertilidade do rebanho, com o uso de
                tecnologia de ponta no aprimoramento das raças Nelore e Angus, e pelos resultados expressivos em
                qualidade da carne e produtividade do gado.
              </p>
            </Reveal>

            <dl className="mt-10 divide-y divide-white/[0.09] border-y border-white/[0.09]">
              {livestockFacts.map((f) => (
                <div key={f.label} className="grid grid-cols-[8.5rem_1fr] gap-4 py-4">
                  <dt className="text-[0.85rem] font-semibold text-stone">{f.label}</dt>
                  <dd className="text-[0.98rem] leading-snug text-sand/90">{f.value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-10">
              <Button to="/pecuaria" variant="outline">
                Conheça a pecuária
              </Button>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="grid grid-cols-2 gap-x-8 gap-y-14">
              {livestockStats.map((s) => (
                <StatItem key={s.id} stat={s} />
              ))}
            </div>
            <p className="mt-12 text-[0.8rem] text-stone">{statsReference}</p>
          </div>
        </div>
      </Container>
    </section>
  );
}
