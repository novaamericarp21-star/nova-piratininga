import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react';
import { ArrowDown } from 'lucide-react';
import { company } from '../data/company';
import { images } from '../data/images';
import { EASE_OUT } from '../lib/motion';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { Magnetic } from '../components/Magnetic';
import { RevealText } from '../components/RevealText';

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '13%']);
  const fade = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  const enter = (delay: number) => ({
    initial: reduce ? false : { opacity: 0, y: 12 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6, delay, ease: EASE_OUT },
  });

  return (
    <section
      ref={ref}
      aria-label="Apresentação"
      className="grain relative isolate flex min-h-[100svh] items-end overflow-hidden"
    >
      {/* Fundo: parallax na rolagem + deriva lenta contínua */}
      <motion.div className="absolute inset-x-0 -top-[15%] -z-10 h-[115%]" style={reduce ? undefined : { y }}>
        <div className="kenburns absolute inset-0">
          <Img image={images.hero} priority className="h-full w-full" />
        </div>
      </motion.div>
      <div className="hero-scrim absolute inset-0 -z-10" />
      <div className="hero-light absolute inset-0 -z-10" />

      <motion.div className="relative z-10 w-full" style={reduce ? undefined : { opacity: fade }}>
        <Container className="pb-16 pt-40 md:pb-24">
          <RevealText as="h1" trigger="mount" delay={0.15} text={'NOVA\nPIRATININGA'} className="display-xxl uppercase" />

          <div className="mt-8 grid items-end gap-8 md:mt-12 lg:grid-cols-12">
            <motion.div className="lg:col-span-6" {...enter(0.75)}>
              <p className="font-display text-[clamp(1.5rem,3vw,2.6rem)] font-light leading-tight text-bone">
                {company.heroLine}
              </p>
              <p className="mt-3 max-w-md text-[1rem] leading-relaxed text-sand/80">{company.heroContext}</p>
            </motion.div>

            <motion.div className="flex flex-wrap items-center gap-3 lg:col-span-6 lg:justify-end" {...enter(0.9)}>
              <Magnetic>
                <Button to="/sobre">Conheça a Nova Piratininga</Button>
              </Magnetic>
              <Button href="#producao" variant="outline">
                Nossa produção
              </Button>
            </motion.div>
          </div>
        </Container>
      </motion.div>

      <a
        href="#producao"
        className="label-caps absolute bottom-7 right-8 z-10 hidden items-center gap-3 text-[0.68rem] text-sand/70 transition-colors duration-200 ease-out hover:text-bone md:flex xl:right-16"
      >
        Scroll
        <ArrowDown size={15} strokeWidth={1.4} className="scroll-cue-arrow" aria-hidden="true" />
      </a>
    </section>
  );
}
