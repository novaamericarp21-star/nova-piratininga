import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { galleryCategories, galleryImages, type GalleryCategory, type GalleryImage } from '../data/images';
import { EASE_OUT } from '../lib/motion';
import { cn } from '../lib/cn';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { RevealText } from '../components/RevealText';

const ratios = ['aspect-[4/5]', 'aspect-square', 'aspect-[3/4]', 'aspect-[4/3]', 'aspect-[5/4]', 'aspect-[2/3]', 'aspect-[16/11]'];

function Lightbox({
  items,
  index,
  onIndex,
  onClose,
}: {
  items: GalleryImage[];
  index: number;
  onIndex: (i: number) => void;
  onClose: () => void;
}) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const reduce = useReducedMotion();
  const item = items[index];

  useEffect(() => {
    const prev = () => onIndex((index - 1 + items.length) % items.length);
    const next = () => onIndex((index + 1) % items.length);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'ArrowRight') next();
      else if (e.key === 'Tab') {
        const focusables = dialogRef.current?.querySelectorAll<HTMLElement>('button');
        if (!focusables || focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [index, items.length, onIndex, onClose]);

  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  const go = (delta: number) => onIndex((index + delta + items.length) % items.length);
  const navBtn =
    'absolute top-1/2 z-10 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-white/[0.18] bg-ink-950/60 text-bone backdrop-blur-md transition-colors duration-200 ease-out hover:border-white/50 sm:flex';

  return createPortal(
    <motion.div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-label="Galeria de fotos"
      className="fixed inset-0 z-[80] flex items-center justify-center bg-ink-950/95 p-4 sm:p-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: reduce ? 0 : 0.2, ease: EASE_OUT }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <button
        ref={closeRef}
        type="button"
        onClick={onClose}
        aria-label="Fechar galeria"
        className="absolute right-3 top-3 z-10 flex h-12 w-12 items-center justify-center text-bone sm:right-6 sm:top-6"
      >
        <X size={26} strokeWidth={1.3} aria-hidden="true" />
      </button>

      <button type="button" onClick={() => go(-1)} aria-label="Foto anterior" className={cn(navBtn, 'left-4 sm:left-8')}>
        <ChevronLeft size={22} strokeWidth={1.4} aria-hidden="true" />
      </button>
      <button type="button" onClick={() => go(1)} aria-label="Próxima foto" className={cn(navBtn, 'right-4 sm:right-8')}>
        <ChevronRight size={22} strokeWidth={1.4} aria-hidden="true" />
      </button>

      <motion.figure
        key={item.src}
        className="flex max-h-full max-w-full flex-col items-center"
        initial={reduce ? false : { opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.25, ease: EASE_OUT }}
        drag={reduce ? false : 'x'}
        dragSnapToOrigin
        dragElastic={0.18}
        onDragEnd={(_, info) => {
          if (info.offset.x < -70) go(1);
          else if (info.offset.x > 70) go(-1);
        }}
      >
        <img
          src={item.src}
          alt={item.alt}
          draggable={false}
          className="max-h-[78svh] max-w-full object-contain sm:max-h-[82svh]"
        />
        <figcaption className="mt-4 text-center text-[0.85rem] text-stone">
          <span className="tabular-nums">
            {index + 1} / {items.length}
          </span>{' '}
          · {item.category}
        </figcaption>
      </motion.figure>
    </motion.div>,
    document.body,
  );
}

type Props = {
  /** Mostra só uma categoria (páginas internas). */
  only?: GalleryCategory;
  title?: string;
  compact?: boolean;
};

export function Gallery({ only, title = 'Galeria', compact = false }: Props) {
  const base = useMemo(() => galleryImages.filter((i) => !only || i.category === only), [only]);
  // Categorias sem foto ficam ocultas até serem preenchidas em data/images.ts.
  const categories = useMemo(
    () => galleryCategories.filter((c) => base.some((i) => i.category === c)),
    [base],
  );
  const [cat, setCat] = useState<GalleryCategory | 'Todas'>('Todas');
  const items = cat === 'Todas' ? base : base.filter((i) => i.category === cat);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const openerRef = useRef<HTMLElement | null>(null);

  if (base.length === 0) return null;

  const close = () => {
    setOpenIndex(null);
    window.setTimeout(() => openerRef.current?.focus(), 0);
  };

  return (
    <section id="galeria" className="relative scroll-mt-16 py-24 md:py-40">
      <Container>
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <RevealText
            as="h2"
            className={cn(compact ? 'display-lg' : 'display-xl', 'uppercase')}
            text={title}
          />
          {!only && categories.length > 1 && (
            <div role="group" aria-label="Filtrar fotos por categoria" className="flex flex-wrap gap-2">
              {(['Todas', ...categories] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-pressed={cat === c}
                  onClick={() => setCat(c)}
                  className={cn(
                    'label-caps min-h-11 rounded-sm border px-4 text-[0.7rem] transition-[background-color,border-color,color] duration-200 ease-out',
                    cat === c
                      ? 'border-bone bg-bone text-ink-950'
                      : 'border-white/[0.2] text-sand hover:border-white/50 hover:text-bone',
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          )}
        </div>

        <div key={cat} className="page-enter mt-12 columns-2 gap-3 md:columns-3 md:gap-4 lg:gap-5">
          {items.map((item, i) => (
            <button
              key={item.src}
              type="button"
              onClick={(e) => {
                openerRef.current = e.currentTarget;
                setOpenIndex(i);
              }}
              aria-label={`Ampliar foto: ${item.alt}`}
              className="group relative mb-3 block w-full break-inside-avoid overflow-hidden md:mb-4 lg:mb-5"
            >
              <div className="transition-transform duration-700 ease-out group-hover:scale-[1.03]">
                <Img image={item} className={ratios[i % ratios.length]} />
              </div>
              <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink-950/80 to-transparent p-3 text-left text-[0.8rem] text-bone opacity-0 transition-opacity duration-300 ease-out group-hover:opacity-100 group-focus-visible:opacity-100">
                {item.category}
              </span>
            </button>
          ))}
        </div>
      </Container>

      <AnimatePresence>
        {openIndex !== null && (
          <Lightbox key="lightbox" items={items} index={openIndex} onIndex={setOpenIndex} onClose={close} />
        )}
      </AnimatePresence>
    </section>
  );
}
