import { company } from '../data/company';
import { images } from '../data/images';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';
import { TopoLines } from '../components/TopoLines';

const graticule = {
  backgroundImage:
    'linear-gradient(rgba(243,241,233,0.045) 1px, transparent 1px), linear-gradient(90deg, rgba(243,241,233,0.045) 1px, transparent 1px)',
  backgroundSize: '64px 64px',
};

/** Mapa estilizado. Ilustrativo: não representa fronteiras nem coordenadas reais. */
export function TopoMap({ label = true }: { label?: boolean }) {
  return (
    <figure>
      <div className="relative aspect-[5/4] overflow-hidden border border-white/[0.08] bg-ink-950">
        <Img
          image={images.satellite}
          className="absolute inset-0"
          imgClassName="opacity-[0.2] mix-blend-luminosity grayscale"
        />
        <div className="absolute inset-0" style={graticule} aria-hidden="true" />
        <TopoLines
          animate
          className="absolute inset-0 h-full w-full text-moss"
          rings={16}
          step={32}
          cx={500}
          cy={400}
        />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" aria-hidden="true">
          <span className="relative block h-3 w-3">
            <span className="pulse-ring absolute inset-0 rounded-full border border-moss" />
            <span className="absolute inset-0 rounded-full bg-moss" />
          </span>
        </div>
        {label && (
          <p className="absolute left-1/2 top-1/2 ml-5 mt-3 text-[0.8rem] font-medium text-bone">{company.name}</p>
        )}
      </div>
      <figcaption className="mt-3 text-[0.8rem] text-stone">Representação ilustrativa, sem escala.</figcaption>
    </figure>
  );
}

export function MapSection() {
  const { address } = company;
  return (
    <section className="relative bg-ink-900 py-24 md:py-40">
      <Container>
        <div className="grid items-center gap-14 lg:grid-cols-12 lg:gap-20">
          <div className="lg:col-span-7">
            <Reveal>
              <TopoMap />
            </Reveal>
          </div>
          <div className="lg:col-span-5">
            <RevealText as="h2" className="display-lg uppercase" text="Entre Goiás e Tocantins" />
            <Reveal className="mt-8" delay={0.1}>
              <p className="lead">
                A Nova Piratininga está localizada no coração do Brasil, com áreas nos municípios de São Miguel do
                Araguaia e Araguaçu, entre os estados de Goiás e Tocantins.
              </p>
              <dl className="mt-10 divide-y divide-white/[0.09] border-y border-white/[0.09]">
                {company.municipalities.map((m) => (
                  <div key={m.name} className="flex items-baseline justify-between py-4">
                    <dt className="font-display text-[1.35rem] font-light text-bone">{m.name}</dt>
                    <dd className="text-[0.9rem] text-stone">{m.uf}</dd>
                  </div>
                ))}
              </dl>
              <p className="body-copy mt-8">
                Sede em {address.city} ({address.state}): {address.line1}, {address.line2}.{' '}
                <a
                  href={company.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-line text-bone"
                >
                  Ver endereço no mapa
                </a>
              </p>
            </Reveal>
          </div>
        </div>
      </Container>
    </section>
  );
}
