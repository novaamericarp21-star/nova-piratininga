import { techItems } from '../data/content';
import { Container } from '../components/Container';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';
import { TechIcon } from '../components/Icons';
import { TopoLines } from '../components/TopoLines';

export function Technology() {
  return (
    <section id="tecnologia" className="relative isolate scroll-mt-16 overflow-hidden py-24 md:py-40">
      <TopoLines
        className="pointer-events-none absolute -right-[15%] top-0 -z-10 h-full w-[115%] text-forest-600/[0.16]"
        cx={320}
        cy={320}
        rings={18}
        step={36}
        seed={0.7}
      />
      <Container>
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-20">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-32">
              <RevealText as="h2" className="display-lg uppercase" text="Tecnologia no campo" />
              <Reveal className="mt-8" delay={0.1}>
                <p className="lead max-w-md">
                  A tecnologia não é uma área separada: ela atravessa a rotina da fazenda, do rebanho à lavoura.
                </p>
              </Reveal>
            </div>
          </div>

          <ul className="lg:col-span-7">
            {techItems.map((item) => (
              <li
                key={item.id}
                className="group grid grid-cols-[2.75rem_1fr] gap-5 border-t border-white/[0.09] py-7 last:border-b md:grid-cols-[4rem_1fr] md:gap-8"
              >
                <TechIcon
                  id={item.icon}
                  className="h-9 w-9 text-stone transition-colors duration-200 ease-out group-hover:text-moss md:h-11 md:w-11"
                />
                <div className="transition-transform duration-200 ease-out group-hover:translate-x-1">
                  <h3 className="font-display text-[1.45rem] font-light text-bone md:text-[1.75rem]">{item.title}</h3>
                  <p className="body-copy mt-2 max-w-lg">{item.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  );
}
