import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, useMotionValueEvent, useReducedMotion, useScroll, useSpring, useTransform } from 'motion/react';
import { company } from '../data/company';
import { timeline, type TimelineEvent } from '../data/timeline';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { cn } from '../lib/cn';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';
import { TopoLines } from '../components/TopoLines';

const years = Array.from(new Set(timeline.map((e) => e.year)));
const isFirstOfYear = (i: number) => i === 0 || timeline[i - 1].year !== timeline[i].year;
const intro = `Da fundação, em ${company.foundedDate}, às ampliações mais recentes divulgadas pela empresa.`;

function Slide({ event, index }: { event: TimelineEvent; index: number }) {
  const first = isFirstOfYear(index);
  return (
    <article className="w-[clamp(320px,30vw,470px)] shrink-0 pr-12 xl:pr-16">
      <p
        className={cn(
          'font-display font-light leading-[0.9] tracking-[-0.04em] text-[clamp(4rem,13vh,9.5rem)]',
          first ? 'text-bone' : 'year-outline',
        )}
      >
        {event.year}
      </p>
      <div className="mt-5 h-[clamp(150px,25vh,300px)] w-full">
        {event.image ? (
          <Img image={event.image} className="h-full w-full" />
        ) : (
          <div className="relative h-full w-full overflow-hidden border border-white/[0.08]">
            <TopoLines
              className="absolute inset-0 h-full w-full text-moss/40"
              rings={9}
              step={44}
              seed={index * 0.9 + 0.4}
              cx={500}
              cy={400}
            />
          </div>
        )}
      </div>
      <h3 className="mt-5 font-display text-[1.5rem] font-light text-bone">{event.title}</h3>
      <p className="body-copy mt-2 max-w-[38ch] text-[0.95rem] leading-relaxed">{event.text}</p>
    </article>
  );
}

function Horizontal() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const slideRefs = useRef<Array<HTMLElement | null>>([]);
  const offsets = useRef<number[]>([]);
  const distRef = useRef(0);
  const [dist, setDist] = useState(0);
  const [active, setActive] = useState(0);

  const { scrollYProgress } = useScroll({ target: wrapRef, offset: ['start start', 'end end'] });
  const smooth = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.4 });
  const x = useTransform(smooth, (p: number) => -p * distRef.current);

  useEffect(() => {
    const measure = () => {
      const track = trackRef.current;
      if (!track) return;
      const d = Math.max(0, track.scrollWidth - window.innerWidth);
      const base = slideRefs.current[0]?.offsetLeft ?? 0;
      offsets.current = slideRefs.current.map((el) =>
        d > 0 && el ? Math.min(1, Math.max(0, (el.offsetLeft - base) / d)) : 0,
      );
      distRef.current = d;
      setDist(d);
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (trackRef.current) ro.observe(trackRef.current);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, []);

  useMotionValueEvent(scrollYProgress, 'change', (v) => {
    const o = offsets.current;
    let idx = 0;
    for (let i = 0; i < o.length; i++) if (v + 0.02 >= o[i]) idx = i;
    setActive(idx);
  });

  const activeYear = timeline[Math.max(0, active - 1)].year;

  const jumpTo = useCallback((year: number) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const slide = timeline.findIndex((e) => e.year === year) + 1;
    const p = offsets.current[slide] ?? 0;
    const top = wrap.getBoundingClientRect().top + window.scrollY;
    const scrollable = wrap.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + p * scrollable, behavior: 'smooth' });
  }, []);

  return (
    <div ref={wrapRef} style={{ height: `calc(100svh + ${dist}px)` }}>
      <div className="sticky top-0 flex h-[100svh] flex-col justify-center overflow-hidden pb-28 pt-24">
        <motion.div
          ref={trackRef}
          style={{ x }}
          className="flex w-max items-start pl-[max(4rem,6vw)] pr-[12vw]"
        >
          <div
            ref={(el) => {
              slideRefs.current[0] = el;
            }}
            className="w-[clamp(300px,30vw,440px)] shrink-0 self-center pr-16"
          >
            <RevealText as="h2" className="display-lg" text={'Nossa\nhistória'} />
            <p className="lead mt-6 max-w-xs">{intro}</p>
          </div>
          {timeline.map((event, i) => (
            <div
              key={`${event.year}-${event.title}`}
              ref={(el) => {
                slideRefs.current[i + 1] = el;
              }}
            >
              <Slide event={event} index={i} />
            </div>
          ))}
        </motion.div>

        <div className="absolute inset-x-0 bottom-0 px-[max(4rem,6vw)] pb-7">
          <div className="relative h-px w-full bg-white/[0.12]">
            <motion.div className="absolute inset-0 origin-left bg-moss" style={{ scaleX: scrollYProgress }} />
          </div>
          <ul className="mt-2 flex flex-wrap gap-x-2">
            {years.map((y) => (
              <li key={y}>
                <button
                  type="button"
                  onClick={() => jumpTo(y)}
                  aria-current={y === activeYear ? 'true' : undefined}
                  className={cn(
                    'min-h-11 px-3 text-[0.9rem] font-semibold tabular-nums transition-colors duration-200 ease-out',
                    y === activeYear ? 'text-bone' : 'text-stone hover:text-sand',
                  )}
                >
                  {y}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

function Vertical() {
  return (
    <Container className="py-24 md:py-32">
      <RevealText as="h2" className="display-lg" text="Nossa história" />
      <Reveal className="mt-5" delay={0.1}>
        <p className="lead max-w-lg">{intro}</p>
      </Reveal>

      <ol className="relative mt-14 border-l border-white/[0.14] pl-6 sm:pl-10">
        {timeline.map((event, i) => (
          <li key={`${event.year}-${event.title}`} className="relative pb-14 last:pb-0">
            <span className="absolute left-[calc(-1.5rem-4px)] top-3 h-2 w-2 rounded-full bg-moss sm:left-[calc(-2.5rem-4px)]" />
            <Reveal>
              <p
                className={cn(
                  'font-display text-[clamp(3.5rem,14vw,6rem)] font-light leading-none tracking-[-0.04em]',
                  isFirstOfYear(i) ? 'text-bone' : 'year-outline',
                )}
              >
                {event.year}
              </p>
              {event.image && <Img image={event.image} className="mt-5 aspect-[16/10] max-w-xl" />}
              <h3 className="mt-5 font-display text-[1.5rem] font-light text-bone">{event.title}</h3>
              <p className="body-copy mt-2 max-w-md">{event.text}</p>
            </Reveal>
          </li>
        ))}
      </ol>
    </Container>
  );
}

/** Linha do tempo: horizontal e guiada pela rolagem no desktop; vertical no mobile e com movimento reduzido. */
export function Timeline() {
  const desktop = useMediaQuery('(min-width: 1024px)');
  const reduce = useReducedMotion();
  return (
    <section id="historia" className="relative scroll-mt-16 bg-ink-900">
      {desktop && !reduce ? <Horizontal /> : <Vertical />}
    </section>
  );
}
