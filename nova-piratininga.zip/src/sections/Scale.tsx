import { Link } from 'react-router-dom';
import { images } from '../data/images';
import { scalePillars } from '../data/content';
import { company } from '../data/company';
import { ClipReveal, Reveal } from '../components/Reveal';
import { Container } from '../components/Container';
import { ParallaxImg } from '../components/ParallaxImg';
import { RevealText } from '../components/RevealText';

const cell =
  'group relative block pt-7 before:absolute before:left-0 before:top-[-1px] before:h-px before:w-0 before:bg-moss ' +
  'before:transition-[width] before:duration-300 before:ease-out hover:before:w-full focus-visible:before:w-full';

function PillarBody({ title, text }: { title: string; text: string }) {
  return (
    <div className="transition-transform duration-200 ease-out group-hover:translate-x-1">
      <h3 className="font-display text-[1.65rem] font-light text-bone transition-colors duration-200 ease-out group-hover:text-moss">
        {title}
      </h3>
      <p className="mt-3 max-w-[30ch] text-[0.98rem] leading-relaxed text-sand/75">{text}</p>
    </div>
  );
}

export function Scale() {
  return (
    <section id="producao" className="relative scroll-mt-16 py-24 md:py-40">
      <Container>
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5 lg:pt-8">
            <RevealText as="h2" className="display-lg" text="Uma operação construída para o futuro." />
            <Reveal className="mt-8 max-w-lg space-y-5" delay={0.1}>
              <p className="lead">{company.description}</p>
              <p className="body-copy">
                Fundada em {company.foundedDate} e localizada em Goiás e Tocantins, constrói sua história com base na
                dedicação e na eficiência do time, na busca contínua por inovação e controle de qualidade e na promoção
                da responsabilidade socioambiental.
              </p>
            </Reveal>
          </div>
          <div className="lg:col-span-7">
            <ClipReveal>
              <ParallaxImg image={images.operation} className="aspect-[4/3] md:aspect-[16/11]" />
            </ClipReveal>
          </div>
        </div>

        <ul className="mt-20 grid gap-x-10 gap-y-12 border-t border-white/[0.09] sm:grid-cols-2 lg:mt-28 lg:grid-cols-4">
          {scalePillars.map((p) => (
            <li key={p.id}>
              {p.href.startsWith('/') ? (
                <Link to={p.href} className={cell}>
                  <PillarBody title={p.title} text={p.text} />
                </Link>
              ) : (
                <a href={p.href} className={cell}>
                  <PillarBody title={p.title} text={p.text} />
                </a>
              )}
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
