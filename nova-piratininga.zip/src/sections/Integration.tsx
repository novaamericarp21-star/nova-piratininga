import { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { images } from '../data/images';
import { EASE_OUT } from '../lib/motion';
import { cn } from '../lib/cn';
import { Container } from '../components/Container';
import { Img } from '../components/Img';
import { Reveal } from '../components/Reveal';
import { RevealText } from '../components/RevealText';

// Seis curvas que atravessam o centro; a segunda metade espelha a primeira.
const ys = [110, 190, 262, 338, 410, 490];
const curves = ys.map((a) => `M90 ${a} C 300 ${a} 400 280 500 280 C 600 280 700 ${560 - a} 910 ${560 - a}`);

const facts = [
  {
    title: '2019',
    text: 'A integração lavoura-pecuária começou com 3 mil hectares de soja plantada.',
  },
  {
    title: 'Milho e forragem',
    text: 'Na safra 20/21, a fazenda iniciou o plantio de milho, com expectativa de autossuficiência em grão e forragem (silagem e feno) para o rebanho.',
  },
  {
    title: 'Manejo',
    text: 'Sistemas de ILP conduzidos por uma equipe altamente capacitada.',
  },
];

export function Integration() {
  const [hover, setHover] = useState(false);
  const [pinned, setPinned] = useState(false);
  const active = hover || pinned;
  const reduce = useReducedMotion();

  return (
    <section id="integracao" className="relative scroll-mt-16 overflow-hidden bg-ink-900 py-24 md:py-40">
      <Container>
        <div className="max-w-3xl">
          <RevealText as="h2" className="display-lg" text="Lavoura e pecuária, uma só operação." />
          <Reveal className="mt-6" delay={0.1}>
            <p className="lead max-w-xl">
              Na Nova Piratininga, as duas atividades não competem por espaço: elas se sustentam. Passe o mouse ou toque
              em Integração para ver a conexão.
            </p>
          </Reveal>
        </div>

        <div
          className="relative mt-14 grid overflow-hidden border border-white/[0.08] lg:grid-cols-2"
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
        >
          {[
            {
              key: 'lavoura',
              title: 'Lavoura',
              text: 'Soja e milho em larga escala, com agricultura de precisão e armazenagem própria.',
              image: images.agricultureHome,
            },
            {
              key: 'pecuaria',
              title: 'Pecuária',
              text: 'Ciclo completo de cria, recria e engorda, com Nelore e Angus.',
              image: images.livestockHome,
            },
          ].map((panel) => (
            <div key={panel.key} className="relative aspect-[4/5] sm:aspect-[16/10] lg:aspect-auto lg:min-h-[560px]">
              <Img image={panel.image} className="absolute inset-0" />
              <div
                className={cn(
                  'absolute inset-0 bg-ink-950 transition-opacity duration-300 ease-out',
                  active ? 'opacity-[0.42]' : 'opacity-[0.66]',
                )}
              />
              <div className="scrim-bottom absolute inset-0" />
              <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8 lg:p-10">
                <h3 className="display-lg uppercase" style={{ fontSize: 'clamp(1.8rem, 3.6vw, 3.4rem)' }}>
                  {panel.title}
                </h3>
                <p className="mt-3 max-w-[34ch] text-[0.98rem] leading-relaxed text-sand/85">{panel.text}</p>
              </div>
            </div>
          ))}

          {/* Conexão (desktop): linhas que se desenham e partículas discretas */}
          <svg
            viewBox="0 0 1000 560"
            preserveAspectRatio="none"
            className="pointer-events-none absolute inset-0 hidden h-full w-full lg:block"
            aria-hidden="true"
            focusable="false"
            fill="none"
          >
            {curves.map((d, i) => (
              <motion.path
                key={d}
                d={d}
                stroke="#6D9B62"
                strokeWidth={1}
                vectorEffect="non-scaling-stroke"
                initial={false}
                animate={active ? { pathLength: 1, opacity: 0.85 } : { pathLength: 0, opacity: 0 }}
                transition={{ duration: reduce ? 0 : 0.7, delay: active ? i * 0.05 : 0, ease: EASE_OUT }}
              />
            ))}
            {active && !reduce &&
              curves.map((d, i) => (
                <circle key={`p-${i}`} r="2.2" fill="#F3F1E9" opacity="0.9">
                  <animateMotion dur={`${4.2 + i * 0.6}s`} repeatCount="indefinite" path={d} />
                </circle>
              ))}
          </svg>

          <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
            <button
              type="button"
              aria-pressed={pinned}
              onClick={() => setPinned((v) => !v)}
              className={cn(
                'flex h-28 w-28 items-center justify-center rounded-full border text-[0.68rem] font-semibold uppercase tracking-[0.16em] backdrop-blur-md',
                'transition-[background-color,border-color,color] duration-200 ease-out sm:h-32 sm:w-32',
                active
                  ? 'border-moss bg-ink-950/80 text-bone'
                  : 'border-white/[0.3] bg-ink-950/55 text-bone hover:border-white/60',
              )}
            >
              Integração
            </button>
          </div>
        </div>

        <ul className="mt-14 grid gap-10 md:grid-cols-3 md:gap-12">
          {facts.map((f) => (
            <li key={f.title} className="border-t border-white/[0.09] pt-6">
              <h3 className="font-display text-[1.5rem] font-light text-bone">{f.title}</h3>
              <p className="body-copy mt-3 max-w-sm">{f.text}</p>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
