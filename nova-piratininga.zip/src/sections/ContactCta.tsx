import { company } from '../data/company';
import { Button } from '../components/Button';
import { Container } from '../components/Container';
import { RevealText } from '../components/RevealText';
import { TopoLines } from '../components/TopoLines';

export function ContactCta() {
  return (
    <section className="relative isolate overflow-hidden bg-forest-900/60 py-28 md:py-44">
      <TopoLines
        className="pointer-events-none absolute inset-0 -z-10 h-full w-full text-moss/[0.16]"
        cx={780}
        cy={400}
        rings={20}
        step={30}
        seed={3.1}
      />
      <Container>
        <RevealText as="h2" className="display-xl max-w-[12ch]" text="Fale com a Nova Piratininga." />
        <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-5">
          <Button to="/contato">Fale conosco</Button>
          <a
            href={company.phones[0].href}
            className="link-line inline-flex min-h-11 items-center text-[1.05rem] text-bone"
          >
            {company.phones[0].display}
          </a>
        </div>
      </Container>
    </section>
  );
}
