import type { Transition } from 'motion/react';

/** Curva ease-out expressiva: entra rápido, assenta devagar. Nunca linear. */
export const EASE_OUT: [number, number, number, number] = [0.22, 1, 0.36, 1];

/** Mola discreta para elementos que respondem ao ponteiro. */
export const SPRING: Transition = { type: 'spring', stiffness: 380, damping: 32, mass: 0.8 };
