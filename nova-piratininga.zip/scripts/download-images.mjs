// Baixa todas as imagens referenciadas em src/data/images.ts e src/data/*.ts para public/img.
// Uso: npm run images:download  (Node 18+). Depois, defina VITE_LOCAL_IMAGES=true.
import { readFileSync, mkdirSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { join, basename } from 'node:path';

const REMOTE = 'https://novapiratininga.com/wp-content/uploads';
const dataDir = 'src/data';
const outDir = 'public/img';
mkdirSync(outDir, { recursive: true });

const paths = new Set();
for (const file of readdirSync(dataDir)) {
  if (!file.endsWith('.ts')) continue;
  const text = readFileSync(join(dataDir, file), 'utf8');
  for (const m of text.matchAll(/'(\d{4}\/\d{2}\/[^']+)'/g)) paths.add(m[1]);
}

let ok = 0;
let fail = 0;
for (const p of paths) {
  const target = join(outDir, basename(p));
  if (existsSync(target)) continue;
  try {
    const res = await fetch(`${REMOTE}/${p}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    writeFileSync(target, Buffer.from(await res.arrayBuffer()));
    ok += 1;
    console.log('baixada  ', p);
  } catch (err) {
    fail += 1;
    console.warn('falhou   ', p, String(err));
  }
}
console.log(`\nConcluído: ${ok} baixadas, ${fail} falhas, ${paths.size} no total.`);
